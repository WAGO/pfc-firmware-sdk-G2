..
   SPDX-License-Identifier: LGPL-2.1-or-later
   SPDX-FileCopyrightText: 2022 Kent Gibson <warthog618@gmail.com>

..
   This file is part of libgpiod.

   libgpiod documentation master file.

Welcome to libgpiod's documentation!
====================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
