# Fake Function Framework (fff)

- Source: https://raw.githubusercontent.com/meekrosoft/fff/248c7906b40ffed41dab1e9f2457e0c0d7e90ffa/fff.h
- Commit: https://github.com/meekrosoft/fff/commit/248c7906b40ffed41dab1e9f2457e0c0d7e90ffa
- Date: 4 Feb 2017

