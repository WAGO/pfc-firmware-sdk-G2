## Emeritus ##

We would like to acknowledge previous runc maintainers and their huge
contributions to our collective success:

 * Alexander Morozov (@lk4d4)
 * Andrei Vagin (@avagin)
 * Rohit Jnagal (@rjnagal)
 * Victor Marmol (@vmarmol)

We thank these members for their service to the OCI community.
