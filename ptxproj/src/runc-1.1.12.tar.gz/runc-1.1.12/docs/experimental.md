# Experimental features

The following features are experimental and subject to change:

- The `runc features` command (since runc v1.1.0)

The following features were experimental in the past:

Feature                                  | Experimental release | Graduation release
---------------------------------------- | -------------------- | ------------------
cgroup v2                                | v1.0.0-rc91          | v1.0.0-rc93
