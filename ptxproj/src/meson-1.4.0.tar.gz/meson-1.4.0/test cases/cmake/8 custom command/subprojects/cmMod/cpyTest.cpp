#include "cpyTest.hpp"
#include "cpyTest2.hpp"
#include "cpyTest3.hpp"
#include "ccppyyTTeesstt/cpyTest4.hpp"
#include "directory/cpyTest5.hpp"

std::string getStrCpyTest() {
  return CPY_TEST_STR_2 CPY_TEST_STR_3 CPY_TEST_STR_4 CPY_TEST_STR_5;
}
