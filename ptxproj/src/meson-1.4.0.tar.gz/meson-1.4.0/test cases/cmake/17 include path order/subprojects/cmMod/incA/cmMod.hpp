// cmMod.hpp (A)
#pragma once

#error "cmMod.hpp in incA must not be included"
