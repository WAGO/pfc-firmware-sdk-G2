# Packaging for Debian

The packaging for Debian has been removed from this branch. It is now
located in the `debian/sid` branch.
