#!/bin/sh

autoreconf -W portability -visf
