<tr class="noCover">
<td class="line"><a name='1'>1</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;This&nbsp;Source&nbsp;Code&nbsp;Form&nbsp;is&nbsp;subject&nbsp;to&nbsp;the&nbsp;terms&nbsp;of&nbsp;the&nbsp;Mozilla&nbsp;Public</td>
</tr>
<tr class="noCover">
<td class="line"><a name='2'>2</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;License,&nbsp;v.&nbsp;2.0.&nbsp;If&nbsp;a&nbsp;copy&nbsp;of&nbsp;the&nbsp;MPL&nbsp;was&nbsp;not&nbsp;distributed&nbsp;with&nbsp;this</td>
</tr>
<tr class="noCover">
<td class="line"><a name='3'>3</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;file,&nbsp;You&nbsp;can&nbsp;obtain&nbsp;one&nbsp;at&nbsp;http://mozilla.org/MPL/2.0/.</td>
</tr>
<tr class="noCover">
<td class="line"><a name='4'>4</a></td>
<td class="hits"></td>
<td class="code">//</td>
</tr>
<tr class="noCover">
<td class="line"><a name='5'>5</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;Copyright&nbsp;(c)&nbsp;2018-2022&nbsp;WAGO&nbsp;GmbH&nbsp;&amp;&nbsp;Co.&nbsp;KG</td>
</tr>
<tr class="noCover">
<td class="line"><a name='6'>6</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='7'>7</a></td>
<td class="hits"></td>
<td class="code">#include&nbsp;"mdm_config_types.h"</td>
</tr>
<tr class="noCover">
<td class="line"><a name='8'>8</a></td>
<td class="hits"></td>
<td class="code">#include&nbsp;&lt;boost/optional.hpp&gt;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='9'>9</a></td>
<td class="hits"></td>
<td class="code">#include&nbsp;&lt;string&gt;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='10'>10</a></td>
<td class="hits"></td>
<td class="code">#include&nbsp;"mdm_parameter_storage.h"</td>
</tr>
<tr class="noCover">
<td class="line"><a name='11'>11</a></td>
<td class="hits"></td>
<td class="code">#include&nbsp;"parameter_storage.h"</td>
</tr>
<tr class="noCover">
<td class="line"><a name='12'>12</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='13'>13</a></td>
<td class="hits"></td>
<td class="code">constexpr&nbsp;auto&nbsp;KEY_LOG_LEVEL&nbsp;=&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"log_level";</td>
</tr>
<tr class="noCover">
<td class="line"><a name='14'>14</a></td>
<td class="hits"></td>
<td class="code">constexpr&nbsp;auto&nbsp;KEY_PORT_STATE&nbsp;=&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"port_state";</td>
</tr>
<tr class="noCover">
<td class="line"><a name='15'>15</a></td>
<td class="hits"></td>
<td class="code">constexpr&nbsp;auto&nbsp;KEY_SIM_ICCID&nbsp;=&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"sim_iccid";</td>
</tr>
<tr class="noCover">
<td class="line"><a name='16'>16</a></td>
<td class="hits"></td>
<td class="code">constexpr&nbsp;auto&nbsp;KEY_SIM_PIN&nbsp;=&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"sim_pin";</td>
</tr>
<tr class="noCover">
<td class="line"><a name='17'>17</a></td>
<td class="hits"></td>
<td class="code">constexpr&nbsp;auto&nbsp;KEY_NET_SELECTION_MODE&nbsp;=&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"net_selection_mode";</td>
</tr>
<tr class="noCover">
<td class="line"><a name='18'>18</a></td>
<td class="hits"></td>
<td class="code">constexpr&nbsp;auto&nbsp;KEY_NET_MANUAL_OPER&nbsp;=&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"net_manual_oper";</td>
</tr>
<tr class="noCover">
<td class="line"><a name='19'>19</a></td>
<td class="hits"></td>
<td class="code">constexpr&nbsp;auto&nbsp;KEY_NET_MANUAL_ACT&nbsp;=&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"net_manual_act";</td>
</tr>
<tr class="noCover">
<td class="line"><a name='20'>20</a></td>
<td class="hits"></td>
<td class="code">constexpr&nbsp;auto&nbsp;KEY_NET_AUTOSELECT_SCANMODE&nbsp;=&nbsp;"net_autoselect_scanmode";</td>
</tr>
<tr class="noCover">
<td class="line"><a name='21'>21</a></td>
<td class="hits"></td>
<td class="code">constexpr&nbsp;auto&nbsp;KEY_NET_AUTOSELECT_SCANSEQ&nbsp;=&nbsp;&nbsp;"net_autoselect_scanseq";</td>
</tr>
<tr class="noCover">
<td class="line"><a name='22'>22</a></td>
<td class="hits"></td>
<td class="code">constexpr&nbsp;auto&nbsp;KEY_GPRS_STATE&nbsp;=&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"gprs_state";</td>
</tr>
<tr class="noCover">
<td class="line"><a name='23'>23</a></td>
<td class="hits"></td>
<td class="code">constexpr&nbsp;auto&nbsp;KEY_GPRS_APN&nbsp;=&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"gprs_apn";</td>
</tr>
<tr class="noCover">
<td class="line"><a name='24'>24</a></td>
<td class="hits"></td>
<td class="code">constexpr&nbsp;auto&nbsp;KEY_GPRS_AUTH&nbsp;=&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"gprs_auth_type";</td>
</tr>
<tr class="noCover">
<td class="line"><a name='25'>25</a></td>
<td class="hits"></td>
<td class="code">constexpr&nbsp;auto&nbsp;KEY_GPRS_USER&nbsp;=&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"gprs_username";</td>
</tr>
<tr class="noCover">
<td class="line"><a name='26'>26</a></td>
<td class="hits"></td>
<td class="code">constexpr&nbsp;auto&nbsp;KEY_GPRS_PASS&nbsp;=&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"gprs_password";</td>
</tr>
<tr class="noCover">
<td class="line"><a name='27'>27</a></td>
<td class="hits"></td>
<td class="code">constexpr&nbsp;auto&nbsp;KEY_SMS_CNMI_MODE&nbsp;=&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"sms_cnmi_mode";</td>
</tr>
<tr class="noCover">
<td class="line"><a name='28'>28</a></td>
<td class="hits"></td>
<td class="code">constexpr&nbsp;auto&nbsp;KEY_SMS_CNMI_MT&nbsp;=&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"sms_cnmi_mt";</td>
</tr>
<tr class="noCover">
<td class="line"><a name='29'>29</a></td>
<td class="hits"></td>
<td class="code">constexpr&nbsp;auto&nbsp;KEY_SMS_CNMI_BM&nbsp;=&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"sms_cnmi_bm";</td>
</tr>
<tr class="noCover">
<td class="line"><a name='30'>30</a></td>
<td class="hits"></td>
<td class="code">constexpr&nbsp;auto&nbsp;KEY_SMS_CNMI_DS&nbsp;=&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"sms_cnmi_ds";</td>
</tr>
<tr class="noCover">
<td class="line"><a name='31'>31</a></td>
<td class="hits"></td>
<td class="code">constexpr&nbsp;auto&nbsp;KEY_SMS_CNMI_BFR&nbsp;=&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"sms_cnmi_bfr";</td>
</tr>
<tr class="noCover">
<td class="line"><a name='32'>32</a></td>
<td class="hits"></td>
<td class="code">constexpr&nbsp;auto&nbsp;KEY_SMS_CPMS_MEM1&nbsp;=&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"sms_cpms_mem1";</td>
</tr>
<tr class="noCover">
<td class="line"><a name='33'>33</a></td>
<td class="hits"></td>
<td class="code">constexpr&nbsp;auto&nbsp;KEY_SMS_CPMS_MEM2&nbsp;=&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"sms_cpms_mem2";</td>
</tr>
<tr class="noCover">
<td class="line"><a name='34'>34</a></td>
<td class="hits"></td>
<td class="code">constexpr&nbsp;auto&nbsp;KEY_SMS_CPMS_MEM3&nbsp;=&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"sms_cpms_mem3";</td>
</tr>
<tr class="noCover">
<td class="line"><a name='35'>35</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='36'>36</a></td>
<td class="hits">2</td>
<td class="code">ModemManagementConfig&nbsp;MdmParameterStorage::get_modem_management_config()&nbsp;const</td>
</tr>
<tr class="noCover">
<td class="line"><a name='37'>37</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='38'>38</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;ModemManagementConfig&nbsp;stored_config;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='39'>39</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='40'>40</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;constexpr&nbsp;auto&nbsp;LOG_LEVEL_ERR_WRN_INF&nbsp;=&nbsp;3;&nbsp;&nbsp;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='41'>41</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;boost::optional&lt;const&nbsp;int&gt;&nbsp;logLevel&nbsp;=&nbsp;_storage.get_integer(KEY_LOG_LEVEL);</td>
</tr>
<tr class="coverPart" title="Line 42: Conditional coverage 66% (2/3)">
<td class="line"><a name='42'>42</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stored_config.set_log_level(logLevel&nbsp;?&nbsp;*logLevel&nbsp;:&nbsp;LOG_LEVEL_ERR_WRN_INF);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='43'>43</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='44'>44</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;constexpr&nbsp;auto&nbsp;PORT_STATE_ENABLED&nbsp;=&nbsp;1;&nbsp;&nbsp;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='45'>45</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;boost::optional&lt;const&nbsp;int&gt;&nbsp;portState=&nbsp;_storage.get_integer(KEY_PORT_STATE);</td>
</tr>
<tr class="coverPart" title="Line 46: Conditional coverage 66% (2/3)">
<td class="line"><a name='46'>46</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stored_config.set_port_state(portState&nbsp;?&nbsp;*portState&nbsp;:&nbsp;PORT_STATE_ENABLED);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='47'>47</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='48'>48</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;stored_config;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='49'>49</a></td>
<td class="hits">2</td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='50'>50</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='51'>51</a></td>
<td class="hits">2</td>
<td class="code">void&nbsp;MdmParameterStorage::set_modem_management_config(const&nbsp;ModemManagementConfig&nbsp;&amp;new_config)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='52'>52</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='53'>53</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.set_integer(KEY_LOG_LEVEL,&nbsp;new_config.get_log_level());</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='54'>54</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.set_integer(KEY_PORT_STATE,&nbsp;new_config.get_port_state());</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='55'>55</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.store();</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='56'>56</a></td>
<td class="hits">2</td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='57'>57</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='58'>58</a></td>
<td class="hits">2</td>
<td class="code">SimAutoActivation&nbsp;MdmParameterStorage::get_sim_autoactivation()&nbsp;const</td>
</tr>
<tr class="noCover">
<td class="line"><a name='59'>59</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='60'>60</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;SimAutoActivation&nbsp;stored_config;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='61'>61</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='62'>62</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;constexpr&nbsp;auto&nbsp;DEFAULT_SIM_ICCID&nbsp;=&nbsp;"";</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='63'>63</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;boost::optional&lt;const&nbsp;std::string&gt;&nbsp;iccid&nbsp;=&nbsp;_storage.get_string(KEY_SIM_ICCID);</td>
</tr>
<tr class="coverPart" title="Line 64: Conditional coverage 40% (4/10)">
<td class="line"><a name='64'>64</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stored_config.set_iccid(iccid&nbsp;?&nbsp;*iccid&nbsp;:&nbsp;DEFAULT_SIM_ICCID);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='65'>65</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='66'>66</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;constexpr&nbsp;auto&nbsp;DEFAULT_SIM_PIN&nbsp;=&nbsp;"";</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='67'>67</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;boost::optional&lt;const&nbsp;std::string&gt;&nbsp;simpin&nbsp;=&nbsp;_storage.get_string(KEY_SIM_PIN);</td>
</tr>
<tr class="coverPart" title="Line 68: Conditional coverage 40% (4/10)">
<td class="line"><a name='68'>68</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stored_config.set_pin(simpin&nbsp;?&nbsp;*simpin:&nbsp;DEFAULT_SIM_PIN);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='69'>69</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='70'>70</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;stored_config;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='71'>71</a></td>
<td class="hits">2</td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='72'>72</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='73'>73</a></td>
<td class="hits">2</td>
<td class="code">void&nbsp;MdmParameterStorage::set_sim_autoactivation(const&nbsp;SimAutoActivation&nbsp;&amp;new_config)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='74'>74</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='75'>75</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.set_string(KEY_SIM_ICCID,&nbsp;new_config.get_iccid());</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='76'>76</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.set_string(KEY_SIM_PIN,&nbsp;new_config.get_pin());</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='77'>77</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.store();</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='78'>78</a></td>
<td class="hits">2</td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='79'>79</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='80'>80</a></td>
<td class="hits">2</td>
<td class="code">NetworkAccessConfig&nbsp;MdmParameterStorage::get_network_access_config()&nbsp;const</td>
</tr>
<tr class="noCover">
<td class="line"><a name='81'>81</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='82'>82</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;NetworkAccessConfig&nbsp;stored_config;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='83'>83</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='84'>84</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;constexpr&nbsp;auto&nbsp;NET_SELECTION_MODE_AUTOMATIC&nbsp;=&nbsp;&nbsp;0;&nbsp;//0=AUTOMATIC,&nbsp;1=MANUAL</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='85'>85</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;boost::optional&lt;const&nbsp;int&gt;&nbsp;selection_mode&nbsp;=&nbsp;_storage.get_integer(KEY_NET_SELECTION_MODE);</td>
</tr>
<tr class="coverPart" title="Line 86: Conditional coverage 66% (2/3)">
<td class="line"><a name='86'>86</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stored_config.set_selection_mode(selection_mode&nbsp;?&nbsp;*selection_mode&nbsp;:&nbsp;NET_SELECTION_MODE_AUTOMATIC);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='87'>87</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='88'>88</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;constexpr&nbsp;auto&nbsp;DEFAULT_NET_MANUAL_OPER_NONE&nbsp;=&nbsp;0;&nbsp;//0=NONE,&nbsp;other&nbsp;values&nbsp;see&nbsp;3GPP&nbsp;TS&nbsp;27.007</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='89'>89</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;boost::optional&lt;const&nbsp;int&gt;&nbsp;manual_oper&nbsp;=&nbsp;_storage.get_integer(KEY_NET_MANUAL_OPER);</td>
</tr>
<tr class="coverPart" title="Line 90: Conditional coverage 66% (2/3)">
<td class="line"><a name='90'>90</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stored_config.set_manual_oper(manual_oper&nbsp;?&nbsp;*manual_oper&nbsp;:&nbsp;DEFAULT_NET_MANUAL_OPER_NONE);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='91'>91</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='92'>92</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;constexpr&nbsp;auto&nbsp;DEFAULT_NET_MANUAL_ACT_GSM&nbsp;=&nbsp;0;&nbsp;//0=GSM,&nbsp;2=UMTS,&nbsp;other&nbsp;values&nbsp;see&nbsp;3GPP&nbsp;TS&nbsp;27.007</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='93'>93</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;boost::optional&lt;const&nbsp;int&gt;&nbsp;manual_act&nbsp;=&nbsp;_storage.get_integer(KEY_NET_MANUAL_ACT);</td>
</tr>
<tr class="coverPart" title="Line 94: Conditional coverage 66% (2/3)">
<td class="line"><a name='94'>94</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stored_config.set_manual_act(manual_act&nbsp;?&nbsp;*manual_act&nbsp;:&nbsp;DEFAULT_NET_MANUAL_ACT_GSM);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='95'>95</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='96'>96</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;constexpr&nbsp;auto&nbsp;NET_AUTOSELECT_SCANMODE_AUTO&nbsp;=&nbsp;0;&nbsp;//0=AUTO,&nbsp;1=GSM_ONLY,&nbsp;2=UMTS_ONLY</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='97'>97</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;boost::optional&lt;const&nbsp;int&gt;&nbsp;autoselect_scanmode&nbsp;=&nbsp;_storage.get_integer(KEY_NET_AUTOSELECT_SCANMODE);</td>
</tr>
<tr class="coverPart" title="Line 98: Conditional coverage 66% (2/3)">
<td class="line"><a name='98'>98</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stored_config.set_autoselect_scanmode(autoselect_scanmode&nbsp;?&nbsp;*autoselect_scanmode&nbsp;:&nbsp;NET_AUTOSELECT_SCANMODE_AUTO);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='99'>99</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='100'>100</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;constexpr&nbsp;auto&nbsp;NET_AUTOSELECT_SCANSEQ_AUTO&nbsp;=&nbsp;0;&nbsp;//0=AUTO,&nbsp;1=GSM_PRIOR,&nbsp;2=UMTS_PRIOR</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='101'>101</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;boost::optional&lt;const&nbsp;int&gt;&nbsp;autoselect_scanseq&nbsp;=&nbsp;_storage.get_integer(KEY_NET_AUTOSELECT_SCANSEQ);</td>
</tr>
<tr class="coverPart" title="Line 102: Conditional coverage 66% (2/3)">
<td class="line"><a name='102'>102</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stored_config.set_autoselect_scanseq(autoselect_scanseq&nbsp;?&nbsp;*autoselect_scanseq&nbsp;:&nbsp;NET_AUTOSELECT_SCANSEQ_AUTO);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='103'>103</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='104'>104</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;stored_config;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='105'>105</a></td>
<td class="hits">2</td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='106'>106</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='107'>107</a></td>
<td class="hits">2</td>
<td class="code">void&nbsp;MdmParameterStorage::set_network_access_config(const&nbsp;NetworkAccessConfig&nbsp;&amp;new_config)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='108'>108</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='109'>109</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.set_integer(KEY_NET_SELECTION_MODE,&nbsp;new_config.get_selection_mode());</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='110'>110</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.set_integer(KEY_NET_MANUAL_OPER,&nbsp;new_config.get_manual_oper());</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='111'>111</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.set_integer(KEY_NET_MANUAL_ACT,&nbsp;new_config.get_manual_act());</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='112'>112</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.set_integer(KEY_NET_AUTOSELECT_SCANMODE,&nbsp;new_config.get_autoselect_scanmode());</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='113'>113</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.set_integer(KEY_NET_AUTOSELECT_SCANSEQ,&nbsp;new_config.get_autoselect_scanseq());</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='114'>114</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.store();</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='115'>115</a></td>
<td class="hits">2</td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='116'>116</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='117'>117</a></td>
<td class="hits">2</td>
<td class="code">GprsAccessConfig&nbsp;MdmParameterStorage::get_gprs_access_config()&nbsp;const</td>
</tr>
<tr class="noCover">
<td class="line"><a name='118'>118</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='119'>119</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;GprsAccessConfig&nbsp;stored_config;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='120'>120</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='121'>121</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;//variable&nbsp;parameters:</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='122'>122</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;constexpr&nbsp;auto&nbsp;GPRS_STATE_ENABLED&nbsp;=&nbsp;1;&nbsp;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='123'>123</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;boost::optional&lt;const&nbsp;int&gt;&nbsp;state&nbsp;=&nbsp;_storage.get_integer(KEY_GPRS_STATE);</td>
</tr>
<tr class="coverPart" title="Line 124: Conditional coverage 66% (2/3)">
<td class="line"><a name='124'>124</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stored_config.set_state(state&nbsp;?&nbsp;*state&nbsp;:&nbsp;GPRS_STATE_ENABLED);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='125'>125</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='126'>126</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;constexpr&nbsp;auto&nbsp;DEFAULT_GPRS_APN&nbsp;=&nbsp;"";</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='127'>127</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;boost::optional&lt;const&nbsp;std::string&gt;&nbsp;apn&nbsp;=&nbsp;_storage.get_string(KEY_GPRS_APN);</td>
</tr>
<tr class="coverPart" title="Line 128: Conditional coverage 40% (4/10)">
<td class="line"><a name='128'>128</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stored_config.set_apn(apn&nbsp;?&nbsp;*apn&nbsp;:&nbsp;DEFAULT_GPRS_APN);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='129'>129</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='130'>130</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;constexpr&nbsp;auto&nbsp;DEFAULT_GPRS_USER&nbsp;=&nbsp;"";</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='131'>131</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;boost::optional&lt;const&nbsp;std::string&gt;&nbsp;user&nbsp;=&nbsp;_storage.get_string(KEY_GPRS_USER);</td>
</tr>
<tr class="coverPart" title="Line 132: Conditional coverage 40% (4/10)">
<td class="line"><a name='132'>132</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stored_config.set_user(user&nbsp;?&nbsp;*user&nbsp;:&nbsp;DEFAULT_GPRS_USER);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='133'>133</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='134'>134</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;constexpr&nbsp;auto&nbsp;DEFAULT_GPRS_PASS&nbsp;=&nbsp;"";</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='135'>135</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;boost::optional&lt;const&nbsp;std::string&gt;&nbsp;pass&nbsp;=&nbsp;_storage.get_string(KEY_GPRS_PASS);</td>
</tr>
<tr class="coverPart" title="Line 136: Conditional coverage 40% (4/10)">
<td class="line"><a name='136'>136</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stored_config.set_pass(pass&nbsp;?&nbsp;*&nbsp;pass&nbsp;:&nbsp;DEFAULT_GPRS_PASS);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='137'>137</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='138'>138</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;constexpr&nbsp;auto&nbsp;GPRS_NO_AUTH&nbsp;=&nbsp;0;&nbsp;&nbsp;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='139'>139</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;boost::optional&lt;const&nbsp;int&gt;&nbsp;auth&nbsp;=&nbsp;_storage.get_integer(KEY_GPRS_AUTH);</td>
</tr>
<tr class="coverPart" title="Line 140: Conditional coverage 66% (2/3)">
<td class="line"><a name='140'>140</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stored_config.set_auth(auth&nbsp;?&nbsp;*auth&nbsp;:&nbsp;GPRS_NO_AUTH);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='141'>141</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='142'>142</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;//constant&nbsp;parameters:</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='143'>143</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;constexpr&nbsp;auto&nbsp;DEFAULT_PROFILE&nbsp;=&nbsp;1;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='144'>144</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stored_config.set_profile(DEFAULT_PROFILE);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='145'>145</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='146'>146</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;stored_config;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='147'>147</a></td>
<td class="hits">2</td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='148'>148</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='149'>149</a></td>
<td class="hits">2</td>
<td class="code">void&nbsp;MdmParameterStorage::set_gprs_access_config(const&nbsp;GprsAccessConfig&nbsp;&amp;new_config)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='150'>150</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='151'>151</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.set_integer(KEY_GPRS_STATE,&nbsp;new_config.get_state());</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='152'>152</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.set_string(KEY_GPRS_APN,&nbsp;new_config.get_apn());</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='153'>153</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.set_string(KEY_GPRS_USER,&nbsp;new_config.get_user());</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='154'>154</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.set_string(KEY_GPRS_PASS,&nbsp;new_config.get_pass());</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='155'>155</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.set_integer(KEY_GPRS_AUTH,&nbsp;new_config.get_auth());</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='156'>156</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.store();</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='157'>157</a></td>
<td class="hits">2</td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='158'>158</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='159'>159</a></td>
<td class="hits">2</td>
<td class="code">SmsEventReportingConfig&nbsp;MdmParameterStorage::get_sms_event_reporting_config()&nbsp;const</td>
</tr>
<tr class="noCover">
<td class="line"><a name='160'>160</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='161'>161</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;SmsEventReportingConfig&nbsp;stored_config;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='162'>162</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='163'>163</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;constexpr&nbsp;auto&nbsp;BUFFER_MSG_IN_TA&nbsp;=&nbsp;0;&nbsp;&nbsp;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='164'>164</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;boost::optional&lt;const&nbsp;int&gt;&nbsp;mode&nbsp;=&nbsp;_storage.get_integer(KEY_SMS_CNMI_MODE);</td>
</tr>
<tr class="coverPart" title="Line 165: Conditional coverage 66% (2/3)">
<td class="line"><a name='165'>165</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stored_config.set_mode(mode&nbsp;?&nbsp;*mode&nbsp;:&nbsp;BUFFER_MSG_IN_TA);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='166'>166</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='167'>167</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;constexpr&nbsp;auto&nbsp;STORE_MSG_WITHOUT_INDICATION&nbsp;=&nbsp;0;&nbsp;&nbsp;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='168'>168</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;boost::optional&lt;const&nbsp;int&gt;&nbsp;mt&nbsp;=&nbsp;_storage.get_integer(KEY_SMS_CNMI_MT);</td>
</tr>
<tr class="coverPart" title="Line 169: Conditional coverage 66% (2/3)">
<td class="line"><a name='169'>169</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stored_config.set_mt(mt&nbsp;?&nbsp;*mt&nbsp;:&nbsp;STORE_MSG_WITHOUT_INDICATION);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='170'>170</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='171'>171</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;constexpr&nbsp;auto&nbsp;NO_INIDICATION_FOR_BROADCAST_MSG&nbsp;=&nbsp;0;&nbsp;&nbsp;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='172'>172</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;boost::optional&lt;const&nbsp;int&gt;&nbsp;bm&nbsp;=&nbsp;_storage.get_integer(KEY_SMS_CNMI_BM);</td>
</tr>
<tr class="coverPart" title="Line 173: Conditional coverage 66% (2/3)">
<td class="line"><a name='173'>173</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stored_config.set_bm(bm&nbsp;?&nbsp;*bm&nbsp;:&nbsp;NO_INIDICATION_FOR_BROADCAST_MSG);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='174'>174</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='175'>175</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;constexpr&nbsp;auto&nbsp;NO_INDICATION_FOR_STATUS&nbsp;=&nbsp;0;&nbsp;&nbsp;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='176'>176</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;boost::optional&lt;const&nbsp;int&gt;&nbsp;ds&nbsp;=&nbsp;_storage.get_integer(KEY_SMS_CNMI_DS);</td>
</tr>
<tr class="coverPart" title="Line 177: Conditional coverage 66% (2/3)">
<td class="line"><a name='177'>177</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stored_config.set_ds(ds&nbsp;?&nbsp;*ds&nbsp;:&nbsp;NO_INDICATION_FOR_STATUS);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='178'>178</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='179'>179</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;constexpr&nbsp;auto&nbsp;KEEP_MSG_IN_BFR&nbsp;=&nbsp;0;&nbsp;&nbsp;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='180'>180</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;boost::optional&lt;const&nbsp;int&gt;&nbsp;bfr&nbsp;=&nbsp;_storage.get_integer(KEY_SMS_CNMI_BFR);</td>
</tr>
<tr class="coverPart" title="Line 181: Conditional coverage 66% (2/3)">
<td class="line"><a name='181'>181</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stored_config.set_bfr(bfr&nbsp;?&nbsp;*bfr&nbsp;:&nbsp;KEEP_MSG_IN_BFR);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='182'>182</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='183'>183</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;stored_config;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='184'>184</a></td>
<td class="hits">2</td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='185'>185</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='186'>186</a></td>
<td class="hits">2</td>
<td class="code">void&nbsp;MdmParameterStorage::set_sms_event_reporting_config(const&nbsp;SmsEventReportingConfig&nbsp;&amp;new_config)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='187'>187</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='188'>188</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.set_integer(KEY_SMS_CNMI_MODE,&nbsp;new_config.get_mode());</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='189'>189</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.set_integer(KEY_SMS_CNMI_MT,&nbsp;new_config.get_mt());</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='190'>190</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.set_integer(KEY_SMS_CNMI_BM,&nbsp;new_config.get_bm());</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='191'>191</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.set_integer(KEY_SMS_CNMI_DS,&nbsp;new_config.get_ds());</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='192'>192</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.set_integer(KEY_SMS_CNMI_BFR,&nbsp;new_config.get_bfr());</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='193'>193</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.store();</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='194'>194</a></td>
<td class="hits">2</td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='195'>195</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='196'>196</a></td>
<td class="hits">2</td>
<td class="code">SmsStorageConfig&nbsp;MdmParameterStorage::get_sms_storage_config()&nbsp;const</td>
</tr>
<tr class="noCover">
<td class="line"><a name='197'>197</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='198'>198</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;SmsStorageConfig&nbsp;stored_config;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='199'>199</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;constexpr&nbsp;auto&nbsp;STORE_SMS_ON_SIM&nbsp;=&nbsp;"SM";&nbsp;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='200'>200</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='201'>201</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;boost::optional&lt;const&nbsp;std::string&gt;&nbsp;mem1&nbsp;=&nbsp;_storage.get_string(KEY_SMS_CPMS_MEM1);</td>
</tr>
<tr class="coverPart" title="Line 202: Conditional coverage 40% (4/10)">
<td class="line"><a name='202'>202</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stored_config.set_mem1(mem1&nbsp;?&nbsp;*mem1&nbsp;:&nbsp;STORE_SMS_ON_SIM);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='203'>203</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='204'>204</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;boost::optional&lt;const&nbsp;std::string&gt;&nbsp;mem2&nbsp;=&nbsp;_storage.get_string(KEY_SMS_CPMS_MEM2);</td>
</tr>
<tr class="coverPart" title="Line 205: Conditional coverage 40% (4/10)">
<td class="line"><a name='205'>205</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stored_config.set_mem2(mem2&nbsp;?&nbsp;*mem2&nbsp;:&nbsp;STORE_SMS_ON_SIM);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='206'>206</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='207'>207</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;boost::optional&lt;const&nbsp;std::string&gt;&nbsp;mem3&nbsp;=&nbsp;_storage.get_string(KEY_SMS_CPMS_MEM3);</td>
</tr>
<tr class="coverPart" title="Line 208: Conditional coverage 40% (4/10)">
<td class="line"><a name='208'>208</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stored_config.set_mem3(mem3&nbsp;?&nbsp;*mem3&nbsp;:&nbsp;STORE_SMS_ON_SIM);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='209'>209</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='210'>210</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;stored_config;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='211'>211</a></td>
<td class="hits">2</td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='212'>212</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='213'>213</a></td>
<td class="hits">2</td>
<td class="code">void&nbsp;MdmParameterStorage::set_sms_storage_config(const&nbsp;SmsStorageConfig&nbsp;&amp;new_config)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='214'>214</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='215'>215</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.set_string(KEY_SMS_CPMS_MEM1,&nbsp;new_config.get_mem1());</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='216'>216</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.set_string(KEY_SMS_CPMS_MEM2,&nbsp;new_config.get_mem2());</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='217'>217</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.set_string(KEY_SMS_CPMS_MEM3,&nbsp;new_config.get_mem3());</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='218'>218</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_storage.store();</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='219'>219</a></td>
<td class="hits">2</td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='220'>220</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='221'>221</a></td>
<td class="hits">0</td>
<td class="code">MessageServiceConfig&nbsp;MdmParameterStorage::get_message_service_config()&nbsp;const</td>
</tr>
<tr class="noCover">
<td class="line"><a name='222'>222</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='223'>223</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;MessageServiceConfig&nbsp;stored_config;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='224'>224</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='225'>225</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;//constant&nbsp;parameters:</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='226'>226</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;constexpr&nbsp;auto&nbsp;DEFAULT_SMS_FORMAT&nbsp;=&nbsp;0;&nbsp;//0=PDU,&nbsp;1=TEXT</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='227'>227</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stored_config.set_sms_format(DEFAULT_SMS_FORMAT);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='228'>228</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='229'>229</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;stored_config;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='230'>230</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
