<tr class="noCover">
<td class="line"><a name='1'>1</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;This&nbsp;Source&nbsp;Code&nbsp;Form&nbsp;is&nbsp;subject&nbsp;to&nbsp;the&nbsp;terms&nbsp;of&nbsp;the&nbsp;Mozilla&nbsp;Public</td>
</tr>
<tr class="noCover">
<td class="line"><a name='2'>2</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;License,&nbsp;v.&nbsp;2.0.&nbsp;If&nbsp;a&nbsp;copy&nbsp;of&nbsp;the&nbsp;MPL&nbsp;was&nbsp;not&nbsp;distributed&nbsp;with&nbsp;this</td>
</tr>
<tr class="noCover">
<td class="line"><a name='3'>3</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;file,&nbsp;You&nbsp;can&nbsp;obtain&nbsp;one&nbsp;at&nbsp;http://mozilla.org/MPL/2.0/.</td>
</tr>
<tr class="noCover">
<td class="line"><a name='4'>4</a></td>
<td class="hits"></td>
<td class="code">//</td>
</tr>
<tr class="noCover">
<td class="line"><a name='5'>5</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;Copyright&nbsp;(c)&nbsp;2018-2022&nbsp;WAGO&nbsp;GmbH&nbsp;&amp;&nbsp;Co.&nbsp;KG</td>
</tr>
<tr class="noCover">
<td class="line"><a name='6'>6</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='7'>7</a></td>
<td class="hits"></td>
<td class="code">#ifndef&nbsp;MDM_CONFIG_TYPES_H</td>
</tr>
<tr class="noCover">
<td class="line"><a name='8'>8</a></td>
<td class="hits"></td>
<td class="code">#define&nbsp;MDM_CONFIG_TYPES_H</td>
</tr>
<tr class="noCover">
<td class="line"><a name='9'>9</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='10'>10</a></td>
<td class="hits"></td>
<td class="code">#include&nbsp;&lt;string&gt;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='11'>11</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='12'>12</a></td>
<td class="hits"></td>
<td class="code">enum&nbsp;class&nbsp;OPER_SEL_MODE</td>
</tr>
<tr class="noCover">
<td class="line"><a name='13'>13</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='14'>14</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;AUTOMATIC&nbsp;=&nbsp;0,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='15'>15</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;MANUAL&nbsp;=&nbsp;1,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='16'>16</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;ONLY_GSM&nbsp;=&nbsp;2,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='17'>17</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;ONLY_UMTS&nbsp;=&nbsp;3,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='18'>18</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;PREFER_GSM&nbsp;=&nbsp;4,&nbsp;&nbsp;/*WAT26409:&nbsp;deprecated&nbsp;option,&nbsp;not&nbsp;removed&nbsp;for&nbsp;settings&nbsp;restore&nbsp;compatibility*/</td>
</tr>
<tr class="noCover">
<td class="line"><a name='19'>19</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;PREFER_UMTS&nbsp;=&nbsp;5,&nbsp;/*WAT26409:&nbsp;deprecated&nbsp;option,&nbsp;not&nbsp;removed&nbsp;for&nbsp;settings&nbsp;restore&nbsp;compatibility*/</td>
</tr>
<tr class="noCover">
<td class="line"><a name='20'>20</a></td>
<td class="hits"></td>
<td class="code">};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='21'>21</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='22'>22</a></td>
<td class="hits"></td>
<td class="code">enum&nbsp;class&nbsp;OPER_SEL_ACT</td>
</tr>
<tr class="noCover">
<td class="line"><a name='23'>23</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='24'>24</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;GSM&nbsp;=&nbsp;0,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='25'>25</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;GSM_COMPACT&nbsp;=&nbsp;1,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='26'>26</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;UMTS&nbsp;=&nbsp;2,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='27'>27</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;GSM_EGPRS&nbsp;=&nbsp;3,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='28'>28</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;UMTS_HSDPA&nbsp;=&nbsp;4,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='29'>29</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;UMTS_HSUPA&nbsp;=&nbsp;5,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='30'>30</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;UMTS_HSPA&nbsp;=&nbsp;6,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='31'>31</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;LTE&nbsp;=&nbsp;7,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='32'>32</a></td>
<td class="hits"></td>
<td class="code">};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='33'>33</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='34'>34</a></td>
<td class="hits"></td>
<td class="code">enum&nbsp;class&nbsp;NW_SCAN_MODE</td>
</tr>
<tr class="noCover">
<td class="line"><a name='35'>35</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='36'>36</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;AUTO&nbsp;=&nbsp;0,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='37'>37</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;GSM_ONLY&nbsp;=&nbsp;1,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='38'>38</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;UMTS_ONLY&nbsp;=&nbsp;2,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='39'>39</a></td>
<td class="hits"></td>
<td class="code">};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='40'>40</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='41'>41</a></td>
<td class="hits"></td>
<td class="code">enum&nbsp;class&nbsp;NW_SCAN_SEQ</td>
</tr>
<tr class="noCover">
<td class="line"><a name='42'>42</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='43'>43</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;AUTO&nbsp;=&nbsp;0,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='44'>44</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;GSM_PRIOR&nbsp;=&nbsp;1,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='45'>45</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;UMTS_PRIOR&nbsp;=&nbsp;2,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='46'>46</a></td>
<td class="hits"></td>
<td class="code">};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='47'>47</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='48'>48</a></td>
<td class="hits"></td>
<td class="code">enum&nbsp;class&nbsp;GPRS_ACCESS_STATE</td>
</tr>
<tr class="noCover">
<td class="line"><a name='49'>49</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='50'>50</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;DISABLED&nbsp;=&nbsp;0,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='51'>51</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;ENABLED&nbsp;=&nbsp;1,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='52'>52</a></td>
<td class="hits"></td>
<td class="code">};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='53'>53</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='54'>54</a></td>
<td class="hits"></td>
<td class="code">enum&nbsp;class&nbsp;MODEM_PORT_STATE</td>
</tr>
<tr class="noCover">
<td class="line"><a name='55'>55</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='56'>56</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;DISABLED&nbsp;=&nbsp;0,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='57'>57</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;ENABLED&nbsp;=&nbsp;1,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='58'>58</a></td>
<td class="hits"></td>
<td class="code">};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='59'>59</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='60'>60</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='61'>61</a></td>
<td class="hits"></td>
<td class="code">class&nbsp;GprsAccessConfig</td>
</tr>
<tr class="noCover">
<td class="line"><a name='62'>62</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='63'>63</a></td>
<td class="hits"></td>
<td class="code">public:</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='64'>64</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;explicit&nbsp;GprsAccessConfig(int&nbsp;state&nbsp;=&nbsp;0,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='65'>65</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;apn&nbsp;=&nbsp;"",</td>
</tr>
<tr class="noCover">
<td class="line"><a name='66'>66</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;auth&nbsp;=&nbsp;0,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='67'>67</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;&nbsp;user&nbsp;=&nbsp;"",</td>
</tr>
<tr class="noCover">
<td class="line"><a name='68'>68</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;&nbsp;pass&nbsp;=&nbsp;"",</td>
</tr>
<tr class="noCover">
<td class="line"><a name='69'>69</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;profile&nbsp;=&nbsp;0)</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='70'>70</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;_state(state),</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='71'>71</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_apn(std::move(apn)),</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='72'>72</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_auth(auth),</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='73'>73</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_user(std::move(user)),</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='74'>74</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_pass(std::move(pass)),</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='75'>75</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_profile(profile)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='76'>76</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='77'>77</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='78'>78</a></td>
<td class="hits">12</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;get_state()&nbsp;const&nbsp;noexcept&nbsp;{&nbsp;return&nbsp;_state;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='79'>79</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;get_apn()&nbsp;&nbsp;&nbsp;const&nbsp;noexcept&nbsp;{&nbsp;return&nbsp;_apn;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='80'>80</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;get_auth()&nbsp;&nbsp;const&nbsp;noexcept&nbsp;{&nbsp;return&nbsp;_auth;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='81'>81</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;get_user()&nbsp;&nbsp;const&nbsp;noexcept&nbsp;{&nbsp;return&nbsp;_user;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='82'>82</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;get_pass()&nbsp;&nbsp;const&nbsp;noexcept&nbsp;{&nbsp;return&nbsp;_pass;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='83'>83</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;get_profile()&nbsp;const&nbsp;noexcept&nbsp;{&nbsp;return&nbsp;_profile;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='84'>84</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='85'>85</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_state(const&nbsp;int&nbsp;state)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;noexcept&nbsp;{&nbsp;_state&nbsp;=&nbsp;state;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='86'>86</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_apn(const&nbsp;std::string&amp;&nbsp;apn)&nbsp;&nbsp;&nbsp;noexcept&nbsp;{&nbsp;_apn&nbsp;=&nbsp;apn;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='87'>87</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_auth(const&nbsp;int&nbsp;auth)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;noexcept&nbsp;{&nbsp;_auth&nbsp;=&nbsp;auth;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='88'>88</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_user(const&nbsp;std::string&amp;&nbsp;user)&nbsp;noexcept&nbsp;{&nbsp;_user&nbsp;=&nbsp;user;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='89'>89</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_pass(const&nbsp;std::string&amp;&nbsp;pass)&nbsp;noexcept&nbsp;{&nbsp;_pass&nbsp;=&nbsp;pass;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='90'>90</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_profile(const&nbsp;int&nbsp;profile)&nbsp;&nbsp;&nbsp;&nbsp;noexcept&nbsp;{&nbsp;_profile&nbsp;=&nbsp;profile;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='91'>91</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='92'>92</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;compare(const&nbsp;GprsAccessConfig&nbsp;&amp;config)&nbsp;const&nbsp;noexcept</td>
</tr>
<tr class="noCover">
<td class="line"><a name='93'>93</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='94'>94</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;nbr_of_differences&nbsp;=&nbsp;0;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='95'>95</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_state&nbsp;!=&nbsp;config.get_state())&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='96'>96</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nbr_of_differences++;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='97'>97</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='98'>98</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_apn&nbsp;&nbsp;&nbsp;!=&nbsp;config.get_apn())&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='99'>99</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nbr_of_differences++;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='100'>100</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='101'>101</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_auth&nbsp;&nbsp;!=&nbsp;config.get_auth())&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='102'>102</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nbr_of_differences++;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='103'>103</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='104'>104</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_user&nbsp;&nbsp;!=&nbsp;config.get_user())&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='105'>105</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nbr_of_differences++;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='106'>106</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='107'>107</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_pass&nbsp;&nbsp;!=&nbsp;config.get_pass())&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='108'>108</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nbr_of_differences++;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='109'>109</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='110'>110</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_profile&nbsp;!=&nbsp;config.get_profile())&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='111'>111</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nbr_of_differences++;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='112'>112</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='113'>113</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;nbr_of_differences;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='114'>114</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='115'>115</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='116'>116</a></td>
<td class="hits"></td>
<td class="code">private:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='117'>117</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_state;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='118'>118</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;_apn;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='119'>119</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_auth;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='120'>120</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;_user;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='121'>121</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;_pass;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='122'>122</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_profile;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='123'>123</a></td>
<td class="hits"></td>
<td class="code">};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='124'>124</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='125'>125</a></td>
<td class="hits"></td>
<td class="code">class&nbsp;SmsEventReportingConfig&nbsp;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='126'>126</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='127'>127</a></td>
<td class="hits"></td>
<td class="code">public:</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='128'>128</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;explicit&nbsp;SmsEventReportingConfig(int&nbsp;mode&nbsp;=&nbsp;0,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='129'>129</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;mt&nbsp;=&nbsp;0,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='130'>130</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;bm&nbsp;=&nbsp;0,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='131'>131</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;ds&nbsp;=&nbsp;0,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='132'>132</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;bfr&nbsp;=&nbsp;0)</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='133'>133</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;_mode(mode),</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='134'>134</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_mt(mt),</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='135'>135</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_bm(bm),</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='136'>136</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_ds(ds),</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='137'>137</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_bfr(bfr)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='138'>138</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='139'>139</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='140'>140</a></td>
<td class="hits">12</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;get_mode()&nbsp;const&nbsp;noexcept&nbsp;{&nbsp;return&nbsp;_mode;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='141'>141</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;get_mt()&nbsp;&nbsp;&nbsp;const&nbsp;noexcept&nbsp;{&nbsp;return&nbsp;_mt;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='142'>142</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;get_bm()&nbsp;&nbsp;&nbsp;const&nbsp;noexcept&nbsp;{&nbsp;return&nbsp;_bm;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='143'>143</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;get_ds()&nbsp;&nbsp;&nbsp;const&nbsp;noexcept&nbsp;{&nbsp;return&nbsp;_ds;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='144'>144</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;get_bfr()&nbsp;&nbsp;const&nbsp;noexcept&nbsp;{&nbsp;return&nbsp;_bfr;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='145'>145</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='146'>146</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_mode(const&nbsp;int&nbsp;mode)&nbsp;noexcept&nbsp;{&nbsp;_mode&nbsp;=&nbsp;mode;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='147'>147</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_mt(const&nbsp;int&nbsp;mt)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;noexcept&nbsp;{&nbsp;_mt&nbsp;=&nbsp;mt;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='148'>148</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_bm(const&nbsp;int&nbsp;bm)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;noexcept&nbsp;{&nbsp;_bm&nbsp;=&nbsp;bm;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='149'>149</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_ds(const&nbsp;int&nbsp;ds)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;noexcept&nbsp;{&nbsp;_ds&nbsp;=&nbsp;ds;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='150'>150</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_bfr(const&nbsp;int&nbsp;bfr)&nbsp;&nbsp;&nbsp;noexcept&nbsp;{&nbsp;_bfr&nbsp;=&nbsp;bfr;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='151'>151</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='152'>152</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;compare(const&nbsp;SmsEventReportingConfig&nbsp;&amp;config)&nbsp;const&nbsp;noexcept</td>
</tr>
<tr class="noCover">
<td class="line"><a name='153'>153</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='154'>154</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;nbr_of_differences&nbsp;=&nbsp;0;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='155'>155</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_mode&nbsp;!=&nbsp;config.get_mode())&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='156'>156</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nbr_of_differences++;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='157'>157</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='158'>158</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_mt&nbsp;&nbsp;&nbsp;!=&nbsp;config.get_mt())&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='159'>159</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nbr_of_differences++;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='160'>160</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='161'>161</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_bm&nbsp;&nbsp;!=&nbsp;config.get_bm())&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='162'>162</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nbr_of_differences++;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='163'>163</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='164'>164</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_ds&nbsp;&nbsp;!=&nbsp;config.get_ds())&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='165'>165</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nbr_of_differences++;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='166'>166</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='167'>167</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_bfr&nbsp;&nbsp;!=&nbsp;config.get_bfr())&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='168'>168</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nbr_of_differences++;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='169'>169</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='170'>170</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;nbr_of_differences;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='171'>171</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='172'>172</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='173'>173</a></td>
<td class="hits"></td>
<td class="code">private:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='174'>174</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;_mode;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='175'>175</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;_mt;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='176'>176</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;_bm;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='177'>177</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;_ds;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='178'>178</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;_bfr;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='179'>179</a></td>
<td class="hits"></td>
<td class="code">};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='180'>180</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='181'>181</a></td>
<td class="hits"></td>
<td class="code">class&nbsp;SmsStorageConfig&nbsp;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='182'>182</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='183'>183</a></td>
<td class="hits"></td>
<td class="code">public:</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='184'>184</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;explicit&nbsp;SmsStorageConfig(std::string&nbsp;mem1&nbsp;=&nbsp;"",</td>
</tr>
<tr class="noCover">
<td class="line"><a name='185'>185</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;mem2&nbsp;=&nbsp;"",</td>
</tr>
<tr class="noCover">
<td class="line"><a name='186'>186</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;mem3&nbsp;=&nbsp;"")</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='187'>187</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;_mem1(std::move(mem1)),</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='188'>188</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_mem2(std::move(mem2)),</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='189'>189</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_mem3(std::move(mem3))</td>
</tr>
<tr class="noCover">
<td class="line"><a name='190'>190</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='191'>191</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='192'>192</a></td>
<td class="hits">12</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;get_mem1()&nbsp;const&nbsp;noexcept&nbsp;{&nbsp;return&nbsp;_mem1;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='193'>193</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;get_mem2()&nbsp;const&nbsp;noexcept&nbsp;{&nbsp;return&nbsp;_mem2;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='194'>194</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;get_mem3()&nbsp;const&nbsp;noexcept&nbsp;{&nbsp;return&nbsp;_mem3;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='195'>195</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='196'>196</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_mem1(const&nbsp;std::string&amp;&nbsp;mem1)&nbsp;noexcept&nbsp;{&nbsp;_mem1&nbsp;=&nbsp;mem1;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='197'>197</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_mem2(const&nbsp;std::string&amp;&nbsp;mem2)&nbsp;noexcept&nbsp;{&nbsp;_mem2&nbsp;=&nbsp;mem2;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='198'>198</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_mem3(const&nbsp;std::string&amp;&nbsp;mem3)&nbsp;noexcept&nbsp;{&nbsp;_mem3&nbsp;=&nbsp;mem3;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='199'>199</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='200'>200</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;compare(const&nbsp;SmsStorageConfig&nbsp;&amp;config)&nbsp;const&nbsp;noexcept</td>
</tr>
<tr class="noCover">
<td class="line"><a name='201'>201</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='202'>202</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;nbr_of_differences&nbsp;=&nbsp;0;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='203'>203</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_mem1&nbsp;!=&nbsp;config.get_mem1())&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='204'>204</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nbr_of_differences++;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='205'>205</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='206'>206</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_mem2&nbsp;!=&nbsp;config.get_mem2())&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='207'>207</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nbr_of_differences++;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='208'>208</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='209'>209</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_mem3&nbsp;!=&nbsp;config.get_mem3())&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='210'>210</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nbr_of_differences++;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='211'>211</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='212'>212</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;nbr_of_differences;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='213'>213</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='214'>214</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='215'>215</a></td>
<td class="hits"></td>
<td class="code">private:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='216'>216</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;_mem1;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='217'>217</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;_mem2;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='218'>218</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;_mem3;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='219'>219</a></td>
<td class="hits"></td>
<td class="code">};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='220'>220</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='221'>221</a></td>
<td class="hits"></td>
<td class="code">class&nbsp;MessageServiceConfig</td>
</tr>
<tr class="noCover">
<td class="line"><a name='222'>222</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='223'>223</a></td>
<td class="hits"></td>
<td class="code">public:</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='224'>224</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;explicit&nbsp;MessageServiceConfig(int&nbsp;sms_format&nbsp;=&nbsp;0)</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='225'>225</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;_sms_format(sms_format)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='226'>226</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='227'>227</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='228'>228</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;get_sms_format()&nbsp;const&nbsp;noexcept&nbsp;{&nbsp;return&nbsp;_sms_format;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='229'>229</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='230'>230</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_sms_format(const&nbsp;int&nbsp;sms_format)&nbsp;noexcept&nbsp;{&nbsp;_sms_format&nbsp;=&nbsp;sms_format;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='231'>231</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='232'>232</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;compare(const&nbsp;MessageServiceConfig&nbsp;&amp;config)&nbsp;const&nbsp;noexcept</td>
</tr>
<tr class="noCover">
<td class="line"><a name='233'>233</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='234'>234</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;nbr_of_differences&nbsp;=&nbsp;0;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='235'>235</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_sms_format&nbsp;!=&nbsp;config.get_sms_format())&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='236'>236</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nbr_of_differences++;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='237'>237</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='238'>238</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;nbr_of_differences;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='239'>239</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='240'>240</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='241'>241</a></td>
<td class="hits"></td>
<td class="code">private:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='242'>242</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;_sms_format;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='243'>243</a></td>
<td class="hits"></td>
<td class="code">};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='244'>244</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='245'>245</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='246'>246</a></td>
<td class="hits"></td>
<td class="code">class&nbsp;NetworkAccessConfig&nbsp;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='247'>247</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='248'>248</a></td>
<td class="hits"></td>
<td class="code">public:</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='249'>249</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;explicit&nbsp;NetworkAccessConfig(int&nbsp;selection_mode&nbsp;=&nbsp;0,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='250'>250</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;manual_oper&nbsp;=&nbsp;0,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='251'>251</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;manual_act&nbsp;=&nbsp;0,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='252'>252</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;autoselect_scanmode&nbsp;=&nbsp;0,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='253'>253</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;autoselect_scanseq&nbsp;=&nbsp;0)</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='254'>254</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;_selection_mode(selection_mode),</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='255'>255</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_manual_oper(manual_oper),</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='256'>256</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_manual_act(manual_act),</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='257'>257</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_autoselect_scanmode(autoselect_scanmode),</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='258'>258</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_autoselect_scanseq(autoselect_scanseq)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='259'>259</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='260'>260</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='261'>261</a></td>
<td class="hits">12</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;get_selection_mode()&nbsp;const&nbsp;noexcept&nbsp;{&nbsp;return&nbsp;_selection_mode;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='262'>262</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;get_manual_oper()&nbsp;const&nbsp;noexcept&nbsp;{&nbsp;return&nbsp;_manual_oper;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='263'>263</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;get_manual_act()&nbsp;&nbsp;const&nbsp;noexcept&nbsp;{&nbsp;return&nbsp;_manual_act;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='264'>264</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;get_autoselect_scanmode()&nbsp;&nbsp;const&nbsp;noexcept&nbsp;{&nbsp;return&nbsp;_autoselect_scanmode;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='265'>265</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;get_autoselect_scanseq()&nbsp;&nbsp;const&nbsp;noexcept&nbsp;{&nbsp;return&nbsp;_autoselect_scanseq;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='266'>266</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='267'>267</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_selection_mode(const&nbsp;int&nbsp;selection_mode)&nbsp;noexcept&nbsp;{&nbsp;_selection_mode&nbsp;=&nbsp;selection_mode;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='268'>268</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_manual_oper(const&nbsp;int&nbsp;manual_oper)&nbsp;noexcept&nbsp;{&nbsp;_manual_oper&nbsp;=&nbsp;manual_oper;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='269'>269</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_manual_act(const&nbsp;int&nbsp;manual_act)&nbsp;&nbsp;&nbsp;noexcept&nbsp;{&nbsp;_manual_act&nbsp;=&nbsp;manual_act;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='270'>270</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_autoselect_scanmode(const&nbsp;int&nbsp;autoselect_scanmode)&nbsp;&nbsp;&nbsp;noexcept&nbsp;{&nbsp;_autoselect_scanmode&nbsp;=&nbsp;autoselect_scanmode;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='271'>271</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_autoselect_scanseq(const&nbsp;int&nbsp;autoselect_scanseq)&nbsp;&nbsp;&nbsp;noexcept&nbsp;{&nbsp;_autoselect_scanseq&nbsp;=&nbsp;autoselect_scanseq;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='272'>272</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='273'>273</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;compare(const&nbsp;NetworkAccessConfig&nbsp;&amp;config)&nbsp;const&nbsp;noexcept</td>
</tr>
<tr class="noCover">
<td class="line"><a name='274'>274</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='275'>275</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;nbr_of_differences&nbsp;=&nbsp;0;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='276'>276</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_selection_mode&nbsp;!=&nbsp;config.get_selection_mode())&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='277'>277</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nbr_of_differences++;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='278'>278</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='279'>279</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_manual_oper&nbsp;!=&nbsp;config.get_manual_oper())&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='280'>280</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nbr_of_differences++;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='281'>281</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='282'>282</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_manual_act&nbsp;!=&nbsp;config.get_manual_act())&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='283'>283</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nbr_of_differences++;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='284'>284</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='285'>285</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_autoselect_scanmode&nbsp;!=&nbsp;config.get_autoselect_scanmode())&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='286'>286</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nbr_of_differences++;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='287'>287</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='288'>288</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_autoselect_scanseq&nbsp;!=&nbsp;config.get_autoselect_scanseq())&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='289'>289</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nbr_of_differences++;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='290'>290</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='291'>291</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;nbr_of_differences;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='292'>292</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='293'>293</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='294'>294</a></td>
<td class="hits"></td>
<td class="code">private:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='295'>295</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;_selection_mode;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='296'>296</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;_manual_oper;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='297'>297</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;_manual_act;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='298'>298</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;_autoselect_scanmode;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='299'>299</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;_autoselect_scanseq;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='300'>300</a></td>
<td class="hits"></td>
<td class="code">};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='301'>301</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='302'>302</a></td>
<td class="hits"></td>
<td class="code">class&nbsp;SimAutoActivation&nbsp;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='303'>303</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='304'>304</a></td>
<td class="hits"></td>
<td class="code">public:</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='305'>305</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;explicit&nbsp;SimAutoActivation(std::string&nbsp;iccid&nbsp;=&nbsp;"",</td>
</tr>
<tr class="noCover">
<td class="line"><a name='306'>306</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;pin&nbsp;=&nbsp;"")</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='307'>307</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;_iccid(std::move(iccid)),</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='308'>308</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_pin(std::move(pin))</td>
</tr>
<tr class="noCover">
<td class="line"><a name='309'>309</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='310'>310</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='311'>311</a></td>
<td class="hits">12</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;get_iccid()&nbsp;const&nbsp;noexcept&nbsp;{&nbsp;return&nbsp;_iccid;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='312'>312</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;get_pin()&nbsp;&nbsp;&nbsp;const&nbsp;noexcept&nbsp;{&nbsp;return&nbsp;_pin;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='313'>313</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='314'>314</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_iccid(const&nbsp;std::string&amp;&nbsp;iccid)&nbsp;noexcept&nbsp;{&nbsp;_iccid&nbsp;=&nbsp;iccid;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='315'>315</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_pin(const&nbsp;std::string&amp;&nbsp;pin)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;noexcept&nbsp;{&nbsp;_pin&nbsp;=&nbsp;pin;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='316'>316</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='317'>317</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;compare(const&nbsp;SimAutoActivation&nbsp;&amp;config)&nbsp;const&nbsp;noexcept</td>
</tr>
<tr class="noCover">
<td class="line"><a name='318'>318</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='319'>319</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;nbr_of_differences&nbsp;=&nbsp;0;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='320'>320</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_iccid&nbsp;!=&nbsp;config.get_iccid())&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='321'>321</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nbr_of_differences++;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='322'>322</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='323'>323</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_pin&nbsp;!=&nbsp;config.get_pin())&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='324'>324</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nbr_of_differences++;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='325'>325</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='326'>326</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;nbr_of_differences;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='327'>327</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='328'>328</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='329'>329</a></td>
<td class="hits"></td>
<td class="code">private:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='330'>330</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;_iccid;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='331'>331</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;_pin;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='332'>332</a></td>
<td class="hits"></td>
<td class="code">};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='333'>333</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='334'>334</a></td>
<td class="hits"></td>
<td class="code">class&nbsp;ModemManagementConfig&nbsp;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='335'>335</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='336'>336</a></td>
<td class="hits"></td>
<td class="code">public:</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='337'>337</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;explicit&nbsp;ModemManagementConfig(int&nbsp;log_level&nbsp;=&nbsp;0,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='338'>338</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;port_state&nbsp;=&nbsp;0)</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='339'>339</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;_log_level(log_level),</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='340'>340</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_port_state(port_state)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='341'>341</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='342'>342</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='343'>343</a></td>
<td class="hits">12</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;get_log_level()&nbsp;&nbsp;const&nbsp;noexcept&nbsp;{&nbsp;return&nbsp;_log_level;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='344'>344</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;get_port_state()&nbsp;const&nbsp;noexcept&nbsp;{&nbsp;return&nbsp;_port_state;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='345'>345</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='346'>346</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_log_level(const&nbsp;int&nbsp;log_level)&nbsp;&nbsp;&nbsp;noexcept&nbsp;{&nbsp;_log_level&nbsp;=&nbsp;log_level;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='347'>347</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_port_state(const&nbsp;int&nbsp;port_state)&nbsp;noexcept&nbsp;{&nbsp;_port_state&nbsp;=&nbsp;port_state;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='348'>348</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='349'>349</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;compare(const&nbsp;ModemManagementConfig&nbsp;&amp;config)&nbsp;const&nbsp;noexcept</td>
</tr>
<tr class="noCover">
<td class="line"><a name='350'>350</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='351'>351</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;nbr_of_differences&nbsp;=&nbsp;0;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='352'>352</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_log_level&nbsp;!=&nbsp;config.get_log_level())&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='353'>353</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nbr_of_differences++;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='354'>354</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='355'>355</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_port_state&nbsp;!=&nbsp;config.get_port_state())&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='356'>356</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;nbr_of_differences++;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='357'>357</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='358'>358</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;nbr_of_differences;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='359'>359</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='360'>360</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='361'>361</a></td>
<td class="hits"></td>
<td class="code">private:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='362'>362</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;_log_level;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='363'>363</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;_port_state;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='364'>364</a></td>
<td class="hits"></td>
<td class="code">};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='365'>365</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='366'>366</a></td>
<td class="hits"></td>
<td class="code">#endif</td>
</tr>
<tr class="noCover">
<td class="line"><a name='367'>367</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
