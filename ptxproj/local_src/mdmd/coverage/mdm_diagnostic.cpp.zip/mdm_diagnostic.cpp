<tr class="noCover">
<td class="line"><a name='1'>1</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;This&nbsp;Source&nbsp;Code&nbsp;Form&nbsp;is&nbsp;subject&nbsp;to&nbsp;the&nbsp;terms&nbsp;of&nbsp;the&nbsp;Mozilla&nbsp;Public</td>
</tr>
<tr class="noCover">
<td class="line"><a name='2'>2</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;License,&nbsp;v.&nbsp;2.0.&nbsp;If&nbsp;a&nbsp;copy&nbsp;of&nbsp;the&nbsp;MPL&nbsp;was&nbsp;not&nbsp;distributed&nbsp;with&nbsp;this</td>
</tr>
<tr class="noCover">
<td class="line"><a name='3'>3</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;file,&nbsp;You&nbsp;can&nbsp;obtain&nbsp;one&nbsp;at&nbsp;http://mozilla.org/MPL/2.0/.</td>
</tr>
<tr class="noCover">
<td class="line"><a name='4'>4</a></td>
<td class="hits"></td>
<td class="code">//</td>
</tr>
<tr class="noCover">
<td class="line"><a name='5'>5</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;Copyright&nbsp;(c)&nbsp;2018-2022&nbsp;WAGO&nbsp;GmbH&nbsp;&amp;&nbsp;Co.&nbsp;KG</td>
</tr>
<tr class="noCover">
<td class="line"><a name='6'>6</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='7'>7</a></td>
<td class="hits"></td>
<td class="code">#include&nbsp;"mdm_diagnostic.h"</td>
</tr>
<tr class="noCover">
<td class="line"><a name='8'>8</a></td>
<td class="hits"></td>
<td class="code">extern&nbsp;"C"</td>
</tr>
<tr class="noCover">
<td class="line"><a name='9'>9</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='10'>10</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;#include&nbsp;&lt;diagnostic/diagnostic_API.h&gt;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='11'>11</a></td>
<td class="hits"></td>
<td class="code">}&nbsp;//&nbsp;extern&nbsp;"C"</td>
</tr>
<tr class="noCover">
<td class="line"><a name='12'>12</a></td>
<td class="hits"></td>
<td class="code">#include&nbsp;&lt;array&gt;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='13'>13</a></td>
<td class="hits"></td>
<td class="code">#include&nbsp;&lt;cassert&gt;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='14'>14</a></td>
<td class="hits"></td>
<td class="code">#include&nbsp;&lt;diagnostic/mdmd_diag.h&gt;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='15'>15</a></td>
<td class="hits"></td>
<td class="code">#include&nbsp;&lt;stdint.h&gt;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='16'>16</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='17'>17</a></td>
<td class="hits">54</td>
<td class="code">MdmDiagnostic::MdmDiagnostic()&nbsp;:&nbsp;_errorState(MdmErrorState::NONE)</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='18'>18</a></td>
<td class="hits">54</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;,_accessClass(MdmAccessClass::NONE)</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='19'>19</a></td>
<td class="hits">54</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;,_sigLevel(MdmSignalQualityLevel::NONE)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='20'>20</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='21'>21</a></td>
<td class="hits">54</td>
<td class="code">&nbsp;&nbsp;log_EVENT_Init("mdmd");</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='22'>22</a></td>
<td class="hits">54</td>
<td class="code">&nbsp;&nbsp;int32_t&nbsp;signalLevel&nbsp;=&nbsp;0;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='23'>23</a></td>
<td class="hits">54</td>
<td class="code">&nbsp;&nbsp;log_EVENT_LogIdParam(DIAG_3GMM_OPER_SIGNAL_CHANGE,&nbsp;true,&nbsp;LOG_TYPE_INT32,&nbsp;&amp;signalLevel,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='24'>24</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;LOG_TYPE_INVALID);</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='25'>25</a></td>
<td class="hits">54</td>
<td class="code">&nbsp;&nbsp;log_EVENT_LogId(DIAG_3GMM_OPER_SIGNAL_6_OFF&nbsp;,&nbsp;true);</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='26'>26</a></td>
<td class="hits">54</td>
<td class="code">&nbsp;&nbsp;log_EVENT_LogId(DIAG_3GMM_OPER_SIGNAL_5_OFF&nbsp;,&nbsp;true);</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='27'>27</a></td>
<td class="hits">54</td>
<td class="code">&nbsp;&nbsp;log_EVENT_LogId(DIAG_3GMM_OPER_SIGNAL_4_OFF&nbsp;,&nbsp;true);</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='28'>28</a></td>
<td class="hits">54</td>
<td class="code">&nbsp;&nbsp;log_EVENT_LogId(DIAG_3GMM_OPER_SIGNAL_3_OFF&nbsp;,&nbsp;true);</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='29'>29</a></td>
<td class="hits">54</td>
<td class="code">&nbsp;&nbsp;log_EVENT_LogId(DIAG_3GMM_OPER_SIGNAL_2_OFF&nbsp;,&nbsp;true);</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='30'>30</a></td>
<td class="hits">54</td>
<td class="code">&nbsp;&nbsp;log_EVENT_LogId(DIAG_3GMM_OPER_SIGNAL_1_OFF&nbsp;,&nbsp;true);</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='31'>31</a></td>
<td class="hits">54</td>
<td class="code">&nbsp;&nbsp;log_EVENT_LogId(DIAG_3GMM_OPER_NO_NET,&nbsp;true);</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='32'>32</a></td>
<td class="hits">54</td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='33'>33</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='34'>34</a></td>
<td class="hits">42</td>
<td class="code">void&nbsp;MdmDiagnostic::update_net_led(const&nbsp;MdmAccessClass&nbsp;accessClass,&nbsp;const&nbsp;MdmSignalQualityLevel&nbsp;sigLevel)&nbsp;const</td>
</tr>
<tr class="noCover">
<td class="line"><a name='35'>35</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='36'>36</a></td>
<td class="hits">42</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(sigLevel&nbsp;==&nbsp;MdmSignalQualityLevel::NONE)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='37'>37</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='38'>38</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;log_EVENT_LogId(DIAG_3GMM_OPER_NO_NET,&nbsp;true);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='39'>39</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='40'>40</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;else</td>
</tr>
<tr class="noCover">
<td class="line"><a name='41'>41</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverPart" title="Line 42: Conditional coverage 75% (3/4)">
<td class="line"><a name='42'>42</a></td>
<td class="hits">38</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;switch&nbsp;(accessClass)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='43'>43</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='44'>44</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;default:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='45'>45</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//no&nbsp;break;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='46'>46</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MdmAccessClass::NONE:</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='47'>47</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;log_EVENT_LogId(DIAG_3GMM_OPER_NO_NET,&nbsp;true);</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='48'>48</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='49'>49</a></td>
<td class="hits">26</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MdmAccessClass::GSM:</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='50'>50</a></td>
<td class="hits">26</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;log_EVENT_LogId(DIAG_3GMM_OPER_NET_2G,&nbsp;true);</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='51'>51</a></td>
<td class="hits">26</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='52'>52</a></td>
<td class="hits">10</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MdmAccessClass::UMTS:</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='53'>53</a></td>
<td class="hits">10</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;log_EVENT_LogId(DIAG_3GMM_OPER_NET_3G,&nbsp;true);</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='54'>54</a></td>
<td class="hits">10</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='55'>55</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MdmAccessClass::LTE:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='56'>56</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//to&nbsp;be&nbsp;defined:&nbsp;log_EVENT_LogId(DIAG_3GMM_OPER_NET_4G,&nbsp;true);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='57'>57</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;log_EVENT_LogId(DIAG_3GMM_OPER_NET_3G,&nbsp;true);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='58'>58</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='59'>59</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='60'>60</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='61'>61</a></td>
<td class="hits">42</td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='62'>62</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='63'>63</a></td>
<td class="hits">66</td>
<td class="code">static&nbsp;log_tEventId&nbsp;get_led_on_id(std::size_t&nbsp;led_index)&nbsp;{</td>
</tr>
<tr class="coverPart" title="Line 64: Conditional coverage 50% (1/2)">
<td class="line"><a name='64'>64</a></td>
<td class="hits">66</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;assert(led_index&nbsp;&lt;=&nbsp;5);</td>
</tr>
<tr class="coverPart" title="Line 65: Conditional coverage 85% (6/7)">
<td class="line"><a name='65'>65</a></td>
<td class="hits">66</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;switch(led_index)&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='66'>66</a></td>
<td class="hits">28</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;0:&nbsp;return&nbsp;DIAG_3GMM_OPER_SIGNAL_1_ON;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='67'>67</a></td>
<td class="hits">14</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;1:&nbsp;return&nbsp;DIAG_3GMM_OPER_SIGNAL_2_ON;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='68'>68</a></td>
<td class="hits">12</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;2:&nbsp;return&nbsp;DIAG_3GMM_OPER_SIGNAL_3_ON;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='69'>69</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;3:&nbsp;return&nbsp;DIAG_3GMM_OPER_SIGNAL_4_ON;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='70'>70</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;4:&nbsp;return&nbsp;DIAG_3GMM_OPER_SIGNAL_5_ON;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='71'>71</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;5:&nbsp;return&nbsp;DIAG_3GMM_OPER_SIGNAL_6_ON;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='72'>72</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;default:&nbsp;return&nbsp;0;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='73'>73</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='74'>74</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;0;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='75'>75</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='76'>76</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='77'>77</a></td>
<td class="hits">18</td>
<td class="code">static&nbsp;log_tEventId&nbsp;get_led_off_id(std::size_t&nbsp;led_index)&nbsp;{</td>
</tr>
<tr class="coverPart" title="Line 78: Conditional coverage 50% (1/2)">
<td class="line"><a name='78'>78</a></td>
<td class="hits">18</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;assert(led_index&nbsp;&lt;=&nbsp;5);</td>
</tr>
<tr class="coverPart" title="Line 79: Conditional coverage 85% (6/7)">
<td class="line"><a name='79'>79</a></td>
<td class="hits">18</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;switch(led_index)&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='80'>80</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;0:&nbsp;return&nbsp;DIAG_3GMM_OPER_SIGNAL_1_OFF;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='81'>81</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;1:&nbsp;return&nbsp;DIAG_3GMM_OPER_SIGNAL_2_OFF;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='82'>82</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;2:&nbsp;return&nbsp;DIAG_3GMM_OPER_SIGNAL_3_OFF;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='83'>83</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;3:&nbsp;return&nbsp;DIAG_3GMM_OPER_SIGNAL_4_OFF;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='84'>84</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;4:&nbsp;return&nbsp;DIAG_3GMM_OPER_SIGNAL_5_OFF;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='85'>85</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;5:&nbsp;return&nbsp;DIAG_3GMM_OPER_SIGNAL_6_OFF;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='86'>86</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;default:&nbsp;return&nbsp;0;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='87'>87</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='88'>88</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;0;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='89'>89</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='90'>90</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='91'>91</a></td>
<td class="hits">30</td>
<td class="code">static&nbsp;void&nbsp;turn_signal_leds_on(std::size_t&nbsp;signalLevelOldIndex,&nbsp;std::size_t&nbsp;signalLevelNewIndex)&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='92'>92</a></td>
<td class="hits">96</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;for(std::size_t&nbsp;i&nbsp;=&nbsp;signalLevelOldIndex;&nbsp;i&nbsp;&lt;&nbsp;signalLevelNewIndex;&nbsp;++i){</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='93'>93</a></td>
<td class="hits">66</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;log_EVENT_LogId(get_led_on_id(i),&nbsp;true);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='94'>94</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='95'>95</a></td>
<td class="hits">30</td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='96'>96</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='97'>97</a></td>
<td class="hits">6</td>
<td class="code">static&nbsp;void&nbsp;turn_signal_leds_off(std::size_t&nbsp;signalLevelOldIndex,&nbsp;std::size_t&nbsp;signalLevelNewIndex)&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='98'>98</a></td>
<td class="hits">24</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;for(std::size_t&nbsp;i&nbsp;=&nbsp;signalLevelOldIndex;&nbsp;signalLevelNewIndex&nbsp;&lt;&nbsp;i;&nbsp;--i){</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='99'>99</a></td>
<td class="hits">18</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;log_EVENT_LogId(get_led_off_id(i&nbsp;-&nbsp;1),&nbsp;true);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='100'>100</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='101'>101</a></td>
<td class="hits">6</td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='102'>102</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='103'>103</a></td>
<td class="hits">36</td>
<td class="code">void&nbsp;MdmDiagnostic::update_signal_quality_leds(const&nbsp;MdmSignalQualityLevel&nbsp;sigLevelOld,&nbsp;const&nbsp;MdmSignalQualityLevel&nbsp;sigLevelNew)&nbsp;const</td>
</tr>
<tr class="noCover">
<td class="line"><a name='104'>104</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='105'>105</a></td>
<td class="hits">36</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;const&nbsp;auto&nbsp;signalLevelOldIndex&nbsp;=&nbsp;static_cast&lt;std::size_t&gt;(sigLevelOld);&nbsp;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='106'>106</a></td>
<td class="hits">36</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;const&nbsp;auto&nbsp;signalLevelNewIndex&nbsp;=&nbsp;static_cast&lt;std::size_t&gt;(sigLevelNew);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='107'>107</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverPart" title="Line 108: Conditional coverage 50% (1/2)">
<td class="line"><a name='108'>108</a></td>
<td class="hits">36</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if(signalLevelOldIndex&nbsp;!=&nbsp;signalLevelNewIndex)&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='109'>109</a></td>
<td class="hits">36</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;int32_t&nbsp;signalLevel&nbsp;=&nbsp;static_cast&lt;int32_t&gt;(sigLevelNew);</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='110'>110</a></td>
<td class="hits">36</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;log_EVENT_LogIdParam(DIAG_3GMM_OPER_SIGNAL_CHANGE,&nbsp;true,&nbsp;LOG_TYPE_INT32,&nbsp;&amp;signalLevel,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='111'>111</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;LOG_TYPE_INVALID);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='112'>112</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='113'>113</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='114'>114</a></td>
<td class="hits">36</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if(signalLevelOldIndex&nbsp;&lt;&nbsp;signalLevelNewIndex)&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='115'>115</a></td>
<td class="hits">30</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;turn_signal_leds_on(signalLevelOldIndex,&nbsp;signalLevelNewIndex);</td>
</tr>
<tr class="coverPart" title="Line 116: Conditional coverage 50% (1/2)">
<td class="line"><a name='116'>116</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}&nbsp;else&nbsp;if(signalLevelOldIndex&nbsp;&gt;&nbsp;signalLevelNewIndex)&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='117'>117</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;turn_signal_leds_off(signalLevelOldIndex,&nbsp;signalLevelNewIndex);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='118'>118</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}&nbsp;else&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='119'>119</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//do&nbsp;nothing&nbsp;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='120'>120</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='121'>121</a></td>
<td class="hits">36</td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='122'>122</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='123'>123</a></td>
<td class="hits">40</td>
<td class="code">bool&nbsp;MdmDiagnostic::set_error_state(const&nbsp;MdmErrorState&nbsp;newErrorState)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='124'>124</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='125'>125</a></td>
<td class="hits">40</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;bool&nbsp;state_changed&nbsp;=&nbsp;false;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='126'>126</a></td>
<td class="hits">40</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_errorState&nbsp;!=&nbsp;newErrorState)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='127'>127</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='128'>128</a></td>
<td class="hits">38</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;switch&nbsp;(newErrorState)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='129'>129</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='130'>130</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;default:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='131'>131</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//no&nbsp;break;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='132'>132</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MdmErrorState::NONE:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='133'>133</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//update&nbsp;NET&nbsp;LED&nbsp;when&nbsp;error&nbsp;code&nbsp;is&nbsp;not&nbsp;set&nbsp;anymore</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='134'>134</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;update_net_led(_accessClass,&nbsp;_sigLevel);</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='135'>135</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='136'>136</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MdmErrorState::SIM_REMOVED:</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='137'>137</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;log_EVENT_LogId(DIAG_3GMM_ERR_NOSIM,&nbsp;true);</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='138'>138</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='139'>139</a></td>
<td class="hits">14</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MdmErrorState::SIM_INVALID:</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='140'>140</a></td>
<td class="hits">14</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;log_EVENT_LogId(DIAG_3GMM_ERR_SIM_INVALID,&nbsp;true);</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='141'>141</a></td>
<td class="hits">14</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='142'>142</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MdmErrorState::SIM_PIN_NEEDED:</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='143'>143</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;log_EVENT_LogId(DIAG_3GMM_ERR_SIM_PIN_NEEDED,&nbsp;true);</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='144'>144</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='145'>145</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MdmErrorState::SIM_PUK_NEEDED:</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='146'>146</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;log_EVENT_LogId(DIAG_3GMM_ERR_SIM_PUK_NEEDED,&nbsp;true);</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='147'>147</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='148'>148</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MdmErrorState::SIM_NOT_READY:</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='149'>149</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;log_EVENT_LogId(DIAG_3GMM_ERR_SIM_NOT_READY,&nbsp;true);</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='150'>150</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='151'>151</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MdmErrorState::PORT_NOT_READY:</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='152'>152</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;log_EVENT_LogId(DIAG_3GMM_ERR_PORT_NOT_READY,&nbsp;true);</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='153'>153</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='154'>154</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MdmErrorState::INIT_FAILED:</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='155'>155</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;log_EVENT_LogId(DIAG_3GMM_ERR_INIT_FAIL,&nbsp;true);</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='156'>156</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='157'>157</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MdmErrorState::RESET_FAILED:</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='158'>158</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;log_EVENT_LogId(DIAG_3GMM_ERR_RESET_FAIL,&nbsp;true);</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='159'>159</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='160'>160</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MdmErrorState::NET_NO_SERVICE:</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='161'>161</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;log_EVENT_LogId(DIAG_3GMM_OPER_NO_SERVICE,&nbsp;true);</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='162'>162</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='163'>163</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='164'>164</a></td>
<td class="hits">38</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_errorState&nbsp;=&nbsp;newErrorState;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='165'>165</a></td>
<td class="hits">38</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;state_changed&nbsp;=&nbsp;true;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='166'>166</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='167'>167</a></td>
<td class="hits">40</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;state_changed;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='168'>168</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='169'>169</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='170'>170</a></td>
<td class="hits">40</td>
<td class="code">void&nbsp;MdmDiagnostic::set_access_class(const&nbsp;MdmAccessClass&nbsp;newAccessClass)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='171'>171</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='172'>172</a></td>
<td class="hits">40</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(_accessClass&nbsp;==&nbsp;newAccessClass)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='173'>173</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='174'>174</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='175'>175</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='176'>176</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='177'>177</a></td>
<td class="hits">38</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(_sigLevel&nbsp;!=&nbsp;MdmSignalQualityLevel::NONE)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='178'>178</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='179'>179</a></td>
<td class="hits">34</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(newAccessClass&nbsp;==&nbsp;MdmAccessClass::NONE)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='180'>180</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{&nbsp;//switch&nbsp;off&nbsp;SIGNAL&nbsp;QUALITY&nbsp;LEDs&nbsp;when&nbsp;no&nbsp;network&nbsp;accessClass&nbsp;type&nbsp;is&nbsp;set&nbsp;now</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='181'>181</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;update_signal_quality_leds(_sigLevel,&nbsp;MdmSignalQualityLevel::NONE);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='182'>182</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='183'>183</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='184'>184</a></td>
<td class="hits">34</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_errorState&nbsp;==&nbsp;MdmErrorState::NONE)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='185'>185</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='186'>186</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//update&nbsp;NET&nbsp;LED&nbsp;when&nbsp;error&nbsp;code&nbsp;is&nbsp;not&nbsp;set</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='187'>187</a></td>
<td class="hits">32</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;update_net_led(newAccessClass,&nbsp;_sigLevel);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='188'>188</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='189'>189</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;else</td>
</tr>
<tr class="noCover">
<td class="line"><a name='190'>190</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{&nbsp;//do&nbsp;nothing,&nbsp;NET&nbsp;LED&nbsp;shows&nbsp;prior&nbsp;ERROR&nbsp;blink&nbsp;code&nbsp;or&nbsp;zero&nbsp;signal&nbsp;quality&nbsp;overrides&nbsp;network&nbsp;state</td>
</tr>
<tr class="noCover">
<td class="line"><a name='191'>191</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='192'>192</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='193'>193</a></td>
<td class="hits">34</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(_accessClass&nbsp;==&nbsp;MdmAccessClass::NONE)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='194'>194</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{&nbsp;//switch&nbsp;on&nbsp;SIGNAL&nbsp;QUALITY&nbsp;LEDs&nbsp;when&nbsp;no&nbsp;network&nbsp;accessClass&nbsp;type&nbsp;was&nbsp;set&nbsp;before</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='195'>195</a></td>
<td class="hits">26</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;update_signal_quality_leds(MdmSignalQualityLevel::NONE,&nbsp;_sigLevel);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='196'>196</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='197'>197</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='198'>198</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;else</td>
</tr>
<tr class="noCover">
<td class="line"><a name='199'>199</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{&nbsp;//do&nbsp;nothing,&nbsp;zero&nbsp;signal&nbsp;quality&nbsp;overrides&nbsp;any&nbsp;network&nbsp;state</td>
</tr>
<tr class="noCover">
<td class="line"><a name='200'>200</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='201'>201</a></td>
<td class="hits">38</td>
<td class="code">&nbsp;&nbsp;_accessClass&nbsp;=&nbsp;newAccessClass;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='202'>202</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='203'>203</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='204'>204</a></td>
<td class="hits">38</td>
<td class="code">void&nbsp;MdmDiagnostic::set_signal_quality_level(const&nbsp;MdmSignalQualityLevel&nbsp;newSigLevel)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='205'>205</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='206'>206</a></td>
<td class="hits">38</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(_sigLevel&nbsp;==&nbsp;newSigLevel)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='207'>207</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='208'>208</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='209'>209</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='210'>210</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='211'>211</a></td>
<td class="hits">36</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(_accessClass&nbsp;!=&nbsp;MdmAccessClass::NONE)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='212'>212</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverPart" title="Line 213: Conditional coverage 75% (3/4)">
<td class="line"><a name='213'>213</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;((_sigLevel&nbsp;==&nbsp;MdmSignalQualityLevel::NONE)&nbsp;&amp;&amp;&nbsp;(_errorState&nbsp;==&nbsp;MdmErrorState::NONE))</td>
</tr>
<tr class="noCover">
<td class="line"><a name='214'>214</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='215'>215</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//update&nbsp;NET&nbsp;LED&nbsp;when&nbsp;signal&nbsp;quality&nbsp;changes&nbsp;from&nbsp;zero&nbsp;to&nbsp;any&nbsp;other&nbsp;value&nbsp;and&nbsp;error&nbsp;code&nbsp;is&nbsp;not&nbsp;set</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='216'>216</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;update_net_led(_accessClass,&nbsp;newSigLevel);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='217'>217</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='218'>218</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='219'>219</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;update_signal_quality_leds(_sigLevel,&nbsp;newSigLevel);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='220'>220</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverPart" title="Line 221: Conditional coverage 75% (3/4)">
<td class="line"><a name='221'>221</a></td>
<td class="hits">8</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;((newSigLevel&nbsp;==&nbsp;MdmSignalQualityLevel::NONE)&nbsp;&amp;&amp;&nbsp;(_errorState&nbsp;==&nbsp;MdmErrorState::NONE))</td>
</tr>
<tr class="noCover">
<td class="line"><a name='222'>222</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='223'>223</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//update&nbsp;NET&nbsp;LED&nbsp;when&nbsp;signal&nbsp;quality&nbsp;changes&nbsp;to&nbsp;zero&nbsp;to&nbsp;any&nbsp;other&nbsp;value&nbsp;and&nbsp;error&nbsp;code&nbsp;is&nbsp;not&nbsp;set</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='224'>224</a></td>
<td class="hits">2</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;update_net_led(_accessClass,&nbsp;newSigLevel);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='225'>225</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='226'>226</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='227'>227</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;else</td>
</tr>
<tr class="noCover">
<td class="line"><a name='228'>228</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{&nbsp;//do&nbsp;nothing,&nbsp;SIGNAL&nbsp;QUALITY&nbsp;LEDs&nbsp;should&nbsp;be&nbsp;off&nbsp;when&nbsp;no&nbsp;network&nbsp;accessClass&nbsp;type&nbsp;is&nbsp;set</td>
</tr>
<tr class="noCover">
<td class="line"><a name='229'>229</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='230'>230</a></td>
<td class="hits">36</td>
<td class="code">&nbsp;&nbsp;_sigLevel&nbsp;=&nbsp;newSigLevel;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='231'>231</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='232'>232</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='233'>233</a></td>
<td class="hits"></td>
<td class="code">//----&nbsp;End&nbsp;of&nbsp;source&nbsp;file&nbsp;------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='234'>234</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
