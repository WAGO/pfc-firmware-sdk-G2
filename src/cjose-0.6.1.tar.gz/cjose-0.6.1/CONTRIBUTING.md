# Contributing #

## Before Submitting PR ##

* Run `make clang-format`
* Run `make test`

*NOTE* You must use clang-format 3.9.0. You can download binaries from [here](https://bintray.com/apache/trafficserver/clang-format-tools).
