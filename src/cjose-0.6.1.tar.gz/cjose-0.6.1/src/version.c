/*!
* Copyrights
*
* Portions created or assigned to Cisco Systems, Inc. are
* Copyright (c) 2014-2016 Cisco Systems, Inc.  All Rights Reserved.
*/

#include <cjose/version.h>

const char *cjose_version() { return CJOSE_VERSION; }
