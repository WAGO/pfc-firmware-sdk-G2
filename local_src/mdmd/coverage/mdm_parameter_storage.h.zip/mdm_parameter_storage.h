<tr class="noCover">
<td class="line"><a name='1'>1</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;This&nbsp;Source&nbsp;Code&nbsp;Form&nbsp;is&nbsp;subject&nbsp;to&nbsp;the&nbsp;terms&nbsp;of&nbsp;the&nbsp;Mozilla&nbsp;Public</td>
</tr>
<tr class="noCover">
<td class="line"><a name='2'>2</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;License,&nbsp;v.&nbsp;2.0.&nbsp;If&nbsp;a&nbsp;copy&nbsp;of&nbsp;the&nbsp;MPL&nbsp;was&nbsp;not&nbsp;distributed&nbsp;with&nbsp;this</td>
</tr>
<tr class="noCover">
<td class="line"><a name='3'>3</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;file,&nbsp;You&nbsp;can&nbsp;obtain&nbsp;one&nbsp;at&nbsp;http://mozilla.org/MPL/2.0/.</td>
</tr>
<tr class="noCover">
<td class="line"><a name='4'>4</a></td>
<td class="hits"></td>
<td class="code">//</td>
</tr>
<tr class="noCover">
<td class="line"><a name='5'>5</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;Copyright&nbsp;(c)&nbsp;2018-2022&nbsp;WAGO&nbsp;GmbH&nbsp;&amp;&nbsp;Co.&nbsp;KG</td>
</tr>
<tr class="noCover">
<td class="line"><a name='6'>6</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='7'>7</a></td>
<td class="hits"></td>
<td class="code">#ifndef&nbsp;MDMPARAMETERSTORAGE_H</td>
</tr>
<tr class="noCover">
<td class="line"><a name='8'>8</a></td>
<td class="hits"></td>
<td class="code">#define&nbsp;MDMPARAMETERSTORAGE_H</td>
</tr>
<tr class="noCover">
<td class="line"><a name='9'>9</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='10'>10</a></td>
<td class="hits"></td>
<td class="code">class&nbsp;ParameterStorage;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='11'>11</a></td>
<td class="hits"></td>
<td class="code">class&nbsp;ModemManagementConfig;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='12'>12</a></td>
<td class="hits"></td>
<td class="code">class&nbsp;SimAutoActivation;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='13'>13</a></td>
<td class="hits"></td>
<td class="code">class&nbsp;NetworkAccessConfig;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='14'>14</a></td>
<td class="hits"></td>
<td class="code">class&nbsp;GprsAccessConfig;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='15'>15</a></td>
<td class="hits"></td>
<td class="code">class&nbsp;SmsEventReportingConfig;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='16'>16</a></td>
<td class="hits"></td>
<td class="code">class&nbsp;SmsStorageConfig;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='17'>17</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='18'>18</a></td>
<td class="hits"></td>
<td class="code">class&nbsp;MdmParameterStorage</td>
</tr>
<tr class="noCover">
<td class="line"><a name='19'>19</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='20'>20</a></td>
<td class="hits"></td>
<td class="code">private:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='21'>21</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;ParameterStorage&amp;&nbsp;_storage;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='22'>22</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='23'>23</a></td>
<td class="hits"></td>
<td class="code">public:</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='24'>24</a></td>
<td class="hits">21</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;MdmParameterStorage(ParameterStorage&amp;&nbsp;storage)&nbsp;:&nbsp;_storage(storage)&nbsp;{}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='25'>25</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;~MdmParameterStorage()&nbsp;=&nbsp;default;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='26'>26</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='27'>27</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;ModemManagementConfig&nbsp;get_modem_management_config()&nbsp;const;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='28'>28</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_modem_management_config&nbsp;(const&nbsp;ModemManagementConfig&nbsp;&amp;new_config);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='29'>29</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='30'>30</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;SimAutoActivation&nbsp;get_sim_autoactivation()&nbsp;const;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='31'>31</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_sim_autoactivation(const&nbsp;SimAutoActivation&nbsp;&amp;new_config);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='32'>32</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='33'>33</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;NetworkAccessConfig&nbsp;get_network_access_config()&nbsp;const;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='34'>34</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_network_access_config(const&nbsp;NetworkAccessConfig&nbsp;&amp;new_config);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='35'>35</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='36'>36</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;GprsAccessConfig&nbsp;get_gprs_access_config()&nbsp;const;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='37'>37</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_gprs_access_config(const&nbsp;GprsAccessConfig&nbsp;&amp;new_config);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='38'>38</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='39'>39</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;SmsEventReportingConfig&nbsp;get_sms_event_reporting_config()&nbsp;const;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='40'>40</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_sms_event_reporting_config(const&nbsp;SmsEventReportingConfig&nbsp;&amp;new_config);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='41'>41</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='42'>42</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;SmsStorageConfig&nbsp;get_sms_storage_config()&nbsp;const;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='43'>43</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;void&nbsp;set_sms_storage_config(const&nbsp;SmsStorageConfig&nbsp;&amp;new_config);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='44'>44</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='45'>45</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;MessageServiceConfig&nbsp;get_message_service_config()&nbsp;const;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='46'>46</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='47'>47</a></td>
<td class="hits"></td>
<td class="code">};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='48'>48</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='49'>49</a></td>
<td class="hits"></td>
<td class="code">#endif&nbsp;/*MDMPARAMETERSTORAGE_H*/</td>
</tr>
