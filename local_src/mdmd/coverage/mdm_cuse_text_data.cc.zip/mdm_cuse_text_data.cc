<tr class="noCover">
<td class="line"><a name='1'>1</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='2'>2</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;This&nbsp;Source&nbsp;Code&nbsp;Form&nbsp;is&nbsp;subject&nbsp;to&nbsp;the&nbsp;terms&nbsp;of&nbsp;the&nbsp;Mozilla&nbsp;Public</td>
</tr>
<tr class="noCover">
<td class="line"><a name='3'>3</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;License,&nbsp;v.&nbsp;2.0.&nbsp;If&nbsp;a&nbsp;copy&nbsp;of&nbsp;the&nbsp;MPL&nbsp;was&nbsp;not&nbsp;distributed&nbsp;with&nbsp;this</td>
</tr>
<tr class="noCover">
<td class="line"><a name='4'>4</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;file,&nbsp;You&nbsp;can&nbsp;obtain&nbsp;one&nbsp;at&nbsp;http://mozilla.org/MPL/2.0/.</td>
</tr>
<tr class="noCover">
<td class="line"><a name='5'>5</a></td>
<td class="hits"></td>
<td class="code">//</td>
</tr>
<tr class="noCover">
<td class="line"><a name='6'>6</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;This&nbsp;file&nbsp;is&nbsp;part&nbsp;of&nbsp;project&nbsp;mdmd&nbsp;(PTXdist&nbsp;package&nbsp;mdmd).</td>
</tr>
<tr class="noCover">
<td class="line"><a name='7'>7</a></td>
<td class="hits"></td>
<td class="code">//</td>
</tr>
<tr class="noCover">
<td class="line"><a name='8'>8</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;Copyright&nbsp;(c)&nbsp;2017-2022&nbsp;WAGO&nbsp;GmbH&nbsp;&amp;&nbsp;Co.&nbsp;KG</td>
</tr>
<tr class="noCover">
<td class="line"><a name='9'>9</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='10'>10</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='11'>11</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;\file&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;mdm_cuse_text_data.cc</td>
</tr>
<tr class="noCover">
<td class="line"><a name='12'>12</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='13'>13</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;\brief&nbsp;&nbsp;&nbsp;&nbsp;Text&nbsp;data&nbsp;functions&nbsp;for&nbsp;MDMD&nbsp;CUSE.</td>
</tr>
<tr class="noCover">
<td class="line"><a name='14'>14</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='15'>15</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;\author&nbsp;&nbsp;&nbsp;PEn:&nbsp;WAGO&nbsp;GmbH&nbsp;&amp;&nbsp;Co.&nbsp;KG</td>
</tr>
<tr class="noCover">
<td class="line"><a name='16'>16</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='17'>17</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='18'>18</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='19'>19</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;include&nbsp;files</td>
</tr>
<tr class="noCover">
<td class="line"><a name='20'>20</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='21'>21</a></td>
<td class="hits"></td>
<td class="code">#include&nbsp;"mdm_cuse_text_data.hpp"</td>
</tr>
<tr class="noCover">
<td class="line"><a name='22'>22</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='23'>23</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='24'>24</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;defines;&nbsp;structure,&nbsp;enumeration&nbsp;and&nbsp;type&nbsp;definitions</td>
</tr>
<tr class="noCover">
<td class="line"><a name='25'>25</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='26'>26</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='27'>27</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='28'>28</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;function&nbsp;prototypes</td>
</tr>
<tr class="noCover">
<td class="line"><a name='29'>29</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='30'>30</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='31'>31</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='32'>32</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;macros</td>
</tr>
<tr class="noCover">
<td class="line"><a name='33'>33</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='34'>34</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='35'>35</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='36'>36</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;variables'&nbsp;and&nbsp;constants'&nbsp;definitions</td>
</tr>
<tr class="noCover">
<td class="line"><a name='37'>37</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='38'>38</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='39'>39</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='40'>40</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;function&nbsp;implementation</td>
</tr>
<tr class="noCover">
<td class="line"><a name='41'>41</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='42'>42</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='43'>43</a></td>
<td class="hits">180</td>
<td class="code">int&nbsp;get_line_from_buffer(std::string&nbsp;&amp;read_buffer,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='44'>44</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;&amp;line)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='45'>45</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='46'>46</a></td>
<td class="hits">180</td>
<td class="code">&nbsp;&nbsp;const&nbsp;char&nbsp;*&nbsp;szTerm&nbsp;=&nbsp;"\r\n";&nbsp;//line&nbsp;ends&nbsp;with&nbsp;&lt;CR&gt;&nbsp;or&nbsp;&lt;CR&gt;&lt;LF&gt;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='47'>47</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;size_t&nbsp;pos_next;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='48'>48</a></td>
<td class="hits">180</td>
<td class="code">&nbsp;&nbsp;size_t&nbsp;pos_line_end&nbsp;=&nbsp;read_buffer.find_first_of(szTerm);</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='49'>49</a></td>
<td class="hits">180</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(pos_line_end&nbsp;==&nbsp;std::string::npos)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='50'>50</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='51'>51</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;//line&nbsp;not&nbsp;complete</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='52'>52</a></td>
<td class="hits">12</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;-1;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='53'>53</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='54'>54</a></td>
<td class="hits">168</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(pos_line_end&nbsp;==&nbsp;0)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='55'>55</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='56'>56</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;//empty&nbsp;line</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='57'>57</a></td>
<td class="hits">84</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;line.clear();</td>
</tr>
<tr class="noCover">
<td class="line"><a name='58'>58</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='59'>59</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;else</td>
</tr>
<tr class="noCover">
<td class="line"><a name='60'>60</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='61'>61</a></td>
<td class="hits">84</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;line&nbsp;=&nbsp;read_buffer.substr(0,&nbsp;pos_line_end);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='62'>62</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='63'>63</a></td>
<td class="hits">168</td>
<td class="code">&nbsp;&nbsp;pos_next&nbsp;=&nbsp;read_buffer.find_first_not_of(szTerm,&nbsp;pos_line_end);&nbsp;//find&nbsp;first&nbsp;character&nbsp;of&nbsp;next&nbsp;line</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='64'>64</a></td>
<td class="hits">168</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(pos_next&nbsp;==&nbsp;std::string::npos)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='65'>65</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='66'>66</a></td>
<td class="hits">24</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;read_buffer.clear();</td>
</tr>
<tr class="noCover">
<td class="line"><a name='67'>67</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='68'>68</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;else</td>
</tr>
<tr class="noCover">
<td class="line"><a name='69'>69</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='70'>70</a></td>
<td class="hits">144</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;read_buffer.erase(0,&nbsp;pos_next);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='71'>71</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='72'>72</a></td>
<td class="hits">168</td>
<td class="code">&nbsp;&nbsp;return&nbsp;0;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='73'>73</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='74'>74</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='75'>75</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='76'>76</a></td>
<td class="hits">264</td>
<td class="code">int&nbsp;get_pdu_from_buffer(std::string&nbsp;&amp;read_buffer,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='77'>77</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;&amp;pdu)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='78'>78</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='79'>79</a></td>
<td class="hits">264</td>
<td class="code">&nbsp;&nbsp;const&nbsp;char&nbsp;*&nbsp;szTerm&nbsp;=&nbsp;"\x1a\x1b";&nbsp;//SMS&nbsp;PDU&nbsp;ends&nbsp;with&nbsp;&lt;CTRL+Z&gt;&nbsp;or&nbsp;&lt;ESC&gt;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='80'>80</a></td>
<td class="hits">264</td>
<td class="code">&nbsp;&nbsp;size_t&nbsp;pos_pdu_end&nbsp;=&nbsp;read_buffer.find_first_of(szTerm);</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='81'>81</a></td>
<td class="hits">264</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(pos_pdu_end&nbsp;==&nbsp;std::string::npos)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='82'>82</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='83'>83</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;//PDU&nbsp;not&nbsp;complete</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='84'>84</a></td>
<td class="hits">108</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;-1;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='85'>85</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='86'>86</a></td>
<td class="hits">156</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(pos_pdu_end&nbsp;==&nbsp;0)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='87'>87</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='88'>88</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;//empty&nbsp;PDU</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='89'>89</a></td>
<td class="hits">60</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;pdu.clear();</td>
</tr>
<tr class="noCover">
<td class="line"><a name='90'>90</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='91'>91</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;else</td>
</tr>
<tr class="noCover">
<td class="line"><a name='92'>92</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='93'>93</a></td>
<td class="hits">96</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(read_buffer.at(pos_pdu_end)&nbsp;==&nbsp;'\x1b')</td>
</tr>
<tr class="noCover">
<td class="line"><a name='94'>94</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{&nbsp;//ESC&nbsp;aborts&nbsp;SMS&nbsp;send,&nbsp;return&nbsp;with&nbsp;an&nbsp;empty&nbsp;PDU&nbsp;in&nbsp;this&nbsp;case</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='95'>95</a></td>
<td class="hits">30</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;pdu.clear();</td>
</tr>
<tr class="noCover">
<td class="line"><a name='96'>96</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='97'>97</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;else</td>
</tr>
<tr class="noCover">
<td class="line"><a name='98'>98</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='99'>99</a></td>
<td class="hits">66</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;pdu&nbsp;=&nbsp;read_buffer.substr(0,&nbsp;pos_pdu_end);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='100'>100</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='101'>101</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='102'>102</a></td>
<td class="hits">156</td>
<td class="code">&nbsp;&nbsp;read_buffer.erase(0,&nbsp;(pos_pdu_end&nbsp;+&nbsp;1));</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='103'>103</a></td>
<td class="hits">156</td>
<td class="code">&nbsp;&nbsp;return&nbsp;0;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='104'>104</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='105'>105</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='106'>106</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='107'>107</a></td>
<td class="hits">159</td>
<td class="code">int&nbsp;try_to_get_pdu(std::string&nbsp;&amp;read_buffer,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='108'>108</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;&amp;pdu)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='109'>109</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='110'>110</a></td>
<td class="hits">159</td>
<td class="code">&nbsp;&nbsp;int&nbsp;result&nbsp;=&nbsp;GSM_PDU_MSG_OK;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='111'>111</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='112'>112</a></td>
<td class="hits">159</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(0&nbsp;!=&nbsp;get_pdu_from_buffer(read_buffer,&nbsp;pdu))</td>
</tr>
<tr class="noCover">
<td class="line"><a name='113'>113</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{&nbsp;//unable&nbsp;to&nbsp;get&nbsp;complete&nbsp;PDU</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='114'>114</a></td>
<td class="hits">132</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if(&nbsp;&nbsp;&nbsp;&nbsp;((read_buffer.length()&nbsp;&gt;&nbsp;0)&nbsp;&amp;&amp;&nbsp;(!isdigit(read_buffer[0])))</td>
</tr>
<tr class="coverPart" title="Line 115: Conditional coverage 62% (5/8)">
<td class="line"><a name='115'>115</a></td>
<td class="hits">132</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;((read_buffer.length()&nbsp;&gt;&nbsp;1)&nbsp;&amp;&amp;&nbsp;(!isdigit(read_buffer[1]))))</td>
</tr>
<tr class="noCover">
<td class="line"><a name='116'>116</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{&nbsp;//leading&nbsp;SMSC&nbsp;number&nbsp;length&nbsp;missing&nbsp;-&gt;&nbsp;not&nbsp;a&nbsp;valid&nbsp;PDU,&nbsp;but&nbsp;maybe&nbsp;a&nbsp;tried&nbsp;command</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='117'>117</a></td>
<td class="hits">18</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;result&nbsp;=&nbsp;GSM_PDU_MSG_MISSING_LENGHT;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='118'>118</a></td>
<td class="hits">18</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;pdu.clear();</td>
</tr>
<tr class="noCover">
<td class="line"><a name='119'>119</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='120'>120</a></td>
<td class="hits">48</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;else&nbsp;if(read_buffer.length()&nbsp;&gt;&nbsp;GSM_PDU_MSG_MAX_LENGTH)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='121'>121</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{&nbsp;//body&nbsp;is&nbsp;too&nbsp;long</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='122'>122</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;result&nbsp;=&nbsp;GSM_PDU_MSG_TOO_BIG;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='123'>123</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;pdu.clear();</td>
</tr>
<tr class="noCover">
<td class="line"><a name='124'>124</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='125'>125</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;else</td>
</tr>
<tr class="noCover">
<td class="line"><a name='126'>126</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{&nbsp;//read_buffer&nbsp;is&nbsp;empty&nbsp;or&nbsp;PDU&nbsp;is&nbsp;not&nbsp;yet&nbsp;complete</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='127'>127</a></td>
<td class="hits">42</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;result&nbsp;=&nbsp;GSM_PDU_MSG_INCOMPLETE;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='128'>128</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='129'>129</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='130'>130</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;else</td>
</tr>
<tr class="noCover">
<td class="line"><a name='131'>131</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverPart" title="Line 132: Conditional coverage 50% (1/2)">
<td class="line"><a name='132'>132</a></td>
<td class="hits">141</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if(&nbsp;&nbsp;&nbsp;&nbsp;((pdu.length()&nbsp;&gt;&nbsp;0)&nbsp;&amp;&amp;&nbsp;(pdu.length()&nbsp;&lt;&nbsp;2))</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='133'>133</a></td>
<td class="hits">93</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;((pdu.length()&nbsp;&gt;&nbsp;0)&nbsp;&amp;&amp;&nbsp;!isdigit(pdu[0]))</td>
</tr>
<tr class="coverPart" title="Line 134: Conditional coverage 87% (7/8)">
<td class="line"><a name='134'>134</a></td>
<td class="hits">186</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;((pdu.length()&nbsp;&gt;&nbsp;1)&nbsp;&amp;&amp;&nbsp;!isdigit(pdu[1])))</td>
</tr>
<tr class="noCover">
<td class="line"><a name='135'>135</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{&nbsp;//leading&nbsp;SMSC&nbsp;number&nbsp;length&nbsp;missing&nbsp;-&gt;&nbsp;not&nbsp;a&nbsp;valid&nbsp;PDU,&nbsp;but&nbsp;maybe&nbsp;a&nbsp;tried&nbsp;command</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='136'>136</a></td>
<td class="hits">18</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;result&nbsp;=&nbsp;GSM_PDU_MSG_MISSING_LENGHT;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='137'>137</a></td>
<td class="hits">18</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;pdu.clear();</td>
</tr>
<tr class="noCover">
<td class="line"><a name='138'>138</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='139'>139</a></td>
<td class="hits">93</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if(pdu.length()&nbsp;&gt;&nbsp;GSM_PDU_MSG_MAX_LENGTH)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='140'>140</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{&nbsp;//body&nbsp;is&nbsp;too&nbsp;long</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='141'>141</a></td>
<td class="hits">12</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;result&nbsp;=&nbsp;GSM_PDU_MSG_TOO_BIG;</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='142'>142</a></td>
<td class="hits">12</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;pdu.clear();</td>
</tr>
<tr class="noCover">
<td class="line"><a name='143'>143</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='144'>144</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='145'>145</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='146'>146</a></td>
<td class="hits">159</td>
<td class="code">&nbsp;&nbsp;return&nbsp;result;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='147'>147</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='148'>148</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='149'>149</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='150'>150</a></td>
<td class="hits"></td>
<td class="code">//----&nbsp;End&nbsp;of&nbsp;source&nbsp;file&nbsp;------------------------------------------------------</td>
</tr>
