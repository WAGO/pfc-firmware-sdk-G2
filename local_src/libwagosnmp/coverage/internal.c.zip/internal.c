<tr class="noCover">
<td class="line"><a name='1'>1</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='2'>2</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;Copyright&nbsp;(c)&nbsp;WAGO&nbsp;GmbH&nbsp;&amp;&nbsp;Co.&nbsp;KG</td>
</tr>
<tr class="noCover">
<td class="line"><a name='3'>3</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='4'>4</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;PROPRIETARY&nbsp;RIGHTS&nbsp;are&nbsp;involved&nbsp;in&nbsp;the&nbsp;subject&nbsp;matter&nbsp;of&nbsp;this&nbsp;material.</td>
</tr>
<tr class="noCover">
<td class="line"><a name='5'>5</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;All&nbsp;manufacturing,&nbsp;reproduction,&nbsp;use&nbsp;and&nbsp;sales&nbsp;rights&nbsp;pertaining&nbsp;to&nbsp;this</td>
</tr>
<tr class="noCover">
<td class="line"><a name='6'>6</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;subject&nbsp;matter&nbsp;are&nbsp;governed&nbsp;by&nbsp;the&nbsp;license&nbsp;agreement.&nbsp;The&nbsp;recipient&nbsp;of&nbsp;this</td>
</tr>
<tr class="noCover">
<td class="line"><a name='7'>7</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;software&nbsp;implicitly&nbsp;accepts&nbsp;the&nbsp;terms&nbsp;of&nbsp;the&nbsp;license.</td>
</tr>
<tr class="noCover">
<td class="line"><a name='8'>8</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='9'>9</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='10'>10</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='11'>11</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;\file&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;internal.c</td>
</tr>
<tr class="noCover">
<td class="line"><a name='12'>12</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='13'>13</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;\version&nbsp;&nbsp;$Rev:&nbsp;66937&nbsp;$</td>
</tr>
<tr class="noCover">
<td class="line"><a name='14'>14</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='15'>15</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;\brief&nbsp;&nbsp;&nbsp;&nbsp;&lt;Insert&nbsp;description&nbsp;here&gt;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='16'>16</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='17'>17</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;\author&nbsp;&nbsp;&nbsp;&lt;author&gt;&nbsp;:&nbsp;WAGO&nbsp;GmbH&nbsp;&amp;&nbsp;Co.&nbsp;KG</td>
</tr>
<tr class="noCover">
<td class="line"><a name='18'>18</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='19'>19</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='20'>20</a></td>
<td class="hits"></td>
<td class="code">#include&nbsp;"error.h"</td>
</tr>
<tr class="noCover">
<td class="line"><a name='21'>21</a></td>
<td class="hits"></td>
<td class="code">#include&nbsp;"wagosnmp_API.h"</td>
</tr>
<tr class="noCover">
<td class="line"><a name='22'>22</a></td>
<td class="hits"></td>
<td class="code">#include&nbsp;"wagosnmp_internal.h"</td>
</tr>
<tr class="noCover">
<td class="line"><a name='23'>23</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='24'>24</a></td>
<td class="hits"></td>
<td class="code">INTERNAL_SYM&nbsp;pthread_once_t&nbsp;snmp_is_initialized&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;PTHREAD_ONCE_INIT;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='25'>25</a></td>
<td class="hits"></td>
<td class="code">INTERNAL_SYM&nbsp;pthread_once_t&nbsp;snmp_agent_is_initialized&nbsp;=&nbsp;PTHREAD_ONCE_INIT;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='26'>26</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='27'>27</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;variables'&nbsp;and&nbsp;constants'&nbsp;definitions</td>
</tr>
<tr class="noCover">
<td class="line"><a name='28'>28</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='29'>29</a></td>
<td class="hits"></td>
<td class="code">static&nbsp;const&nbsp;oid&nbsp;objid_sysuptime[]&nbsp;=&nbsp;{1,&nbsp;3,&nbsp;6,&nbsp;1,&nbsp;2,&nbsp;1,&nbsp;1,&nbsp;3,&nbsp;0};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='30'>30</a></td>
<td class="hits"></td>
<td class="code">static&nbsp;const&nbsp;oid&nbsp;objid_snmptrap[]&nbsp;&nbsp;=&nbsp;{1,&nbsp;3,&nbsp;6,&nbsp;1,&nbsp;6,&nbsp;3,&nbsp;1,&nbsp;1,&nbsp;4,&nbsp;1,&nbsp;0};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='31'>31</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='32'>32</a></td>
<td class="hits"></td>
<td class="code">#define&nbsp;USE_OWN_COPY_FUNCTION&nbsp;0</td>
</tr>
<tr class="noCover">
<td class="line"><a name='33'>33</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='34'>34</a></td>
<td class="hits"></td>
<td class="code">//--&nbsp;Function:&nbsp;_SprintReallocValue&nbsp;-----------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='35'>35</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='36'>36</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;Copy/Paste&nbsp;from&nbsp;snmp-&gt;&nbsp;snmplib/mib.c.sprint_realloc_by_type</td>
</tr>
<tr class="noCover">
<td class="line"><a name='37'>37</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;This&nbsp;functions&nbsp;is&nbsp;changed,&nbsp;so&nbsp;that&nbsp;the&nbsp;output&nbsp;will&nbsp;not&nbsp;consider&nbsp;the&nbsp;MIB&nbsp;definitions</td>
</tr>
<tr class="noCover">
<td class="line"><a name='38'>38</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='39'>39</a></td>
<td class="hits"></td>
<td class="code">//-----------------------------------------------------------------------------</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='40'>40</a></td>
<td class="hits">0</td>
<td class="code">static&nbsp;int&nbsp;_SprintReallocValue(u_char&nbsp;**buf,&nbsp;size_t&nbsp;*buf_len,&nbsp;size_t&nbsp;*out_len,&nbsp;int&nbsp;allow_realloc,&nbsp;const&nbsp;oid&nbsp;*objid,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='41'>41</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;size_t&nbsp;objidlen,&nbsp;const&nbsp;netsnmp_variable_list&nbsp;*variable)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='42'>42</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(variable-&gt;type&nbsp;==&nbsp;SNMP_NOSUCHOBJECT)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='43'>43</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;snmp_strcat(buf,&nbsp;buf_len,&nbsp;out_len,&nbsp;allow_realloc,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='44'>44</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(const&nbsp;u_char&nbsp;*)"No&nbsp;Such&nbsp;Object&nbsp;available&nbsp;on&nbsp;this&nbsp;agent&nbsp;at&nbsp;this&nbsp;OID");</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='45'>45</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;}&nbsp;else&nbsp;if&nbsp;(variable-&gt;type&nbsp;==&nbsp;SNMP_NOSUCHINSTANCE)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='46'>46</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;snmp_strcat(buf,&nbsp;buf_len,&nbsp;out_len,&nbsp;allow_realloc,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='47'>47</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(const&nbsp;u_char&nbsp;*)"No&nbsp;Such&nbsp;Instance&nbsp;currently&nbsp;exists&nbsp;at&nbsp;this&nbsp;OID");</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='48'>48</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;}&nbsp;else&nbsp;if&nbsp;(variable-&gt;type&nbsp;==&nbsp;SNMP_ENDOFMIBVIEW)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='49'>49</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;snmp_strcat(buf,&nbsp;buf_len,&nbsp;out_len,&nbsp;allow_realloc,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='50'>50</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(const&nbsp;u_char&nbsp;*)"No&nbsp;more&nbsp;variables&nbsp;left&nbsp;in&nbsp;this&nbsp;MIB&nbsp;View&nbsp;(It&nbsp;is&nbsp;past&nbsp;the&nbsp;end&nbsp;of&nbsp;the&nbsp;MIB&nbsp;tree)");</td>
</tr>
<tr class="noCover">
<td class="line"><a name='51'>51</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}&nbsp;else&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='52'>52</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;sprint_realloc_by_type(buf,&nbsp;buf_len,&nbsp;out_len,&nbsp;allow_realloc,&nbsp;variable,&nbsp;NULL,&nbsp;NULL,&nbsp;NULL);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='53'>53</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='54'>54</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='55'>55</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='56'>56</a></td>
<td class="hits"></td>
<td class="code">//--&nbsp;Function:&nbsp;_CopySnmpVarData&nbsp;-------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='57'>57</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='58'>58</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;Copy&nbsp;nvl&nbsp;Data&nbsp;from&nbsp;the&nbsp;SNMP-created&nbsp;instancies&nbsp;to&nbsp;the&nbsp;PLC-Created&nbsp;instancys!</td>
</tr>
<tr class="noCover">
<td class="line"><a name='59'>59</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='60'>60</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;\param&nbsp;dest:&nbsp;Pointer&nbsp;to&nbsp;the&nbsp;MSG-Instancy</td>
</tr>
<tr class="noCover">
<td class="line"><a name='61'>61</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;\param&nbsp;src:&nbsp;&nbsp;Pointer&nbsp;to&nbsp;the&nbsp;SNMP-Instancy</td>
</tr>
<tr class="noCover">
<td class="line"><a name='62'>62</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='63'>63</a></td>
<td class="hits"></td>
<td class="code">//-----------------------------------------------------------------------------</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='64'>64</a></td>
<td class="hits">0</td>
<td class="code">static&nbsp;void&nbsp;_CopySnmpVarData(tWagoSnmpTranceiver&nbsp;*trcv,&nbsp;netsnmp_variable_list&nbsp;*src)&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='65'>65</a></td>
<td class="hits"></td>
<td class="code">#if&nbsp;USE_OWN_COPY_FUNCTION</td>
</tr>
<tr class="noCover">
<td class="line"><a name='66'>66</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;u_char&nbsp;*strOld&nbsp;=&nbsp;NULL;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='67'>67</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;netsnmp_variable_list&nbsp;*pNext;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='68'>68</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;//&nbsp;perform&nbsp;precheck</td>
</tr>
<tr class="noCover">
<td class="line"><a name='69'>69</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;if&nbsp;(src&nbsp;==&nbsp;NULL)&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='70'>70</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='71'>71</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='72'>72</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='73'>73</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;//&nbsp;Mint&nbsp;the&nbsp;order&nbsp;of&nbsp;this&nbsp;contruct!!!</td>
</tr>
<tr class="noCover">
<td class="line"><a name='74'>74</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;//&nbsp;if&nbsp;we&nbsp;create&nbsp;a&nbsp;new&nbsp;string&nbsp;it&nbsp;may&nbsp;be&nbsp;freed&nbsp;in&nbsp;the&nbsp;IEC-thread!!!</td>
</tr>
<tr class="noCover">
<td class="line"><a name='75'>75</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;//&nbsp;it&nbsp;may&nbsp;end&nbsp;up&nbsp;in&nbsp;a&nbsp;race-condition&nbsp;with&nbsp;duble-free&nbsp;an&nbsp;segvault!!!</td>
</tr>
<tr class="noCover">
<td class="line"><a name='76'>76</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;pNext&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;src-&gt;next_variable;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='77'>77</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;src-&gt;next_variable&nbsp;=&nbsp;NULL;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='78'>78</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='79'>79</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;strOld&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;src-&gt;val.string;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='80'>80</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;src-&gt;val.string&nbsp;=&nbsp;NULL;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='81'>81</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='82'>82</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;memcpy(trcv-&gt;typData,&nbsp;src,&nbsp;sizeof(netsnmp_variable_list));</td>
</tr>
<tr class="noCover">
<td class="line"><a name='83'>83</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='84'>84</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;src-&gt;next_variable&nbsp;=&nbsp;pNext;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='85'>85</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;src-&gt;val.string&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;strOld;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='86'>86</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;if&nbsp;(src-&gt;buf&nbsp;!=&nbsp;src-&gt;val.string)&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='87'>87</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;u_char&nbsp;*pNew&nbsp;=&nbsp;malloc((src-&gt;val_len));</td>
</tr>
<tr class="noCover">
<td class="line"><a name='88'>88</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;memcpy(pNew,&nbsp;src-&gt;val.string,&nbsp;src-&gt;val_len);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='89'>89</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;trcv-&gt;sDataString&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;(char&nbsp;*)pNew;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='90'>90</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;SNMP_TLV(trcv-&gt;typData)-&gt;next_variable&nbsp;=&nbsp;SNMP_TLV(trcv-&gt;typData);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='91'>91</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}&nbsp;else&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='92'>92</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;trcv-&gt;sDataString&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;NULL;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='93'>93</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;SNMP_TLV(trcv-&gt;typData)-&gt;next_variable&nbsp;=&nbsp;NULL;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='94'>94</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='95'>95</a></td>
<td class="hits"></td>
<td class="code">#else</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='96'>96</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(src&nbsp;==&nbsp;NULL)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='97'>97</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='98'>98</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='99'>99</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(SNMP_TLV(trcv-&gt;typData)-&gt;val.string&nbsp;&amp;&amp;&nbsp;SNMP_TLV(trcv-&gt;typData)-&gt;val.string&nbsp;!=&nbsp;SNMP_TLV(trcv-&gt;typData)-&gt;buf)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='100'>100</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;free(SNMP_TLV(trcv-&gt;typData)-&gt;val.string);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='101'>101</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='102'>102</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;(void)snmp_clone_var(src,&nbsp;SNMP_TLV(trcv-&gt;typData));</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='103'>103</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;INTERNAL_DeTwist(SNMP_TLV(trcv-&gt;typData));</td>
</tr>
<tr class="noCover">
<td class="line"><a name='104'>104</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='105'>105</a></td>
<td class="hits"></td>
<td class="code">#endif</td>
</tr>
<tr class="noCover">
<td class="line"><a name='106'>106</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='107'>107</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='108'>108</a></td>
<td class="hits">0</td>
<td class="code">static&nbsp;mqd_t&nbsp;_OpenClientQueue(const&nbsp;char&nbsp;*name,&nbsp;long&nbsp;int&nbsp;msgsz,&nbsp;long&nbsp;int&nbsp;maxmsg)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='109'>109</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;mqd_t&nbsp;ret&nbsp;=&nbsp;-1;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='110'>110</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;struct&nbsp;mq_attr&nbsp;mqAttr;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='111'>111</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;errno&nbsp;=&nbsp;0;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='112'>112</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='113'>113</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;mqAttr.mq_flags&nbsp;&nbsp;&nbsp;=&nbsp;0;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='114'>114</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;mqAttr.mq_maxmsg&nbsp;&nbsp;=&nbsp;maxmsg;&nbsp;&nbsp;//&nbsp;create&nbsp;a&nbsp;good&nbsp;size&nbsp;for&nbsp;the&nbsp;message&nbsp;buffer</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='115'>115</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;mqAttr.mq_msgsize&nbsp;=&nbsp;msgsz;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='116'>116</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;ret&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;mq_open(name,&nbsp;OPEN_CLIENT_MODE,&nbsp;CREAT_MODE,&nbsp;&amp;mqAttr);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='117'>117</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;//&nbsp;SNMP_TRAP_COLDSTART;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='118'>118</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(ret&nbsp;&lt;&nbsp;0)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='119'>119</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;perror("mq_open");</td>
</tr>
<tr class="noCover">
<td class="line"><a name='120'>120</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='121'>121</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='122'>122</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;ret;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='123'>123</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='124'>124</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='125'>125</a></td>
<td class="hits"></td>
<td class="code">//--&nbsp;Function:&nbsp;_SetAuthPriv&nbsp;----------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='126'>126</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='127'>127</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;Set&nbsp;the&nbsp;authority&nbsp;configurations</td>
</tr>
<tr class="noCover">
<td class="line"><a name='128'>128</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='129'>129</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;\param&nbsp;msg&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;actual&nbsp;worked&nbsp;out&nbsp;message</td>
</tr>
<tr class="noCover">
<td class="line"><a name='130'>130</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;\param&nbsp;session&nbsp;&nbsp;pointer&nbsp;to&nbsp;the&nbsp;actaul&nbsp;snmp-session&nbsp;var</td>
</tr>
<tr class="noCover">
<td class="line"><a name='131'>131</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='132'>132</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='133'>133</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;int&nbsp;INTERNAL_SetAuthPriv(tWagoSnmpTranceiver&nbsp;*trcv,&nbsp;netsnmp_session&nbsp;*session)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='134'>134</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;int&nbsp;ret&nbsp;=&nbsp;WAGOSNMP_RETURN_OK;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='135'>135</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;//&nbsp;check&nbsp;if&nbsp;we&nbsp;need&nbsp;to&nbsp;do&nbsp;the&nbsp;auth&nbsp;and&nbsp;priv&nbsp;settings</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='136'>136</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(session-&gt;securityLevel&nbsp;==&nbsp;SNMP_SEC_LEVEL_NOAUTH)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='137'>137</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;ret;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='138'>138</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='139'>139</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='140'>140</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;//&nbsp;set&nbsp;the&nbsp;Authetication&nbsp;variables</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='141'>141</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;switch&nbsp;(trcv-&gt;typAuthProt)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='142'>142</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;WAGOSNMP_AUTH_P_NONE:</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='143'>143</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;session-&gt;securityAuthProto&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;usmNoAuthProtocol;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='144'>144</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;session-&gt;securityAuthProtoLen&nbsp;=&nbsp;sizeof(usmNoAuthProtocol)&nbsp;/&nbsp;sizeof(oid);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='145'>145</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='146'>146</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;WAGOSNMP_AUTH_P_MD5:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='147'>147</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/*&nbsp;set&nbsp;the&nbsp;authentication&nbsp;method&nbsp;to&nbsp;MD5&nbsp;*/</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='148'>148</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;session-&gt;securityAuthProto&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;usmHMACMD5AuthProtocol;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='149'>149</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;session-&gt;securityAuthProtoLen&nbsp;=&nbsp;sizeof(usmHMACMD5AuthProtocol)&nbsp;/&nbsp;sizeof(oid);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='150'>150</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='151'>151</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;WAGOSNMP_AUTH_P_SHA:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='152'>152</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/*&nbsp;set&nbsp;the&nbsp;authentication&nbsp;method&nbsp;to&nbsp;MD5&nbsp;*/</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='153'>153</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;session-&gt;securityAuthProto&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;usmHMACSHA1AuthProtocol;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='154'>154</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;session-&gt;securityAuthProtoLen&nbsp;=&nbsp;sizeof(usmHMACSHA1AuthProtocol)&nbsp;/&nbsp;sizeof(oid);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='155'>155</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='156'>156</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;default:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='157'>157</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;waht&nbsp;to&nbsp;do&nbsp;in&nbsp;case&nbsp;of&nbsp;error??</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='158'>158</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='159'>159</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='160'>160</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;session-&gt;securityAuthKeyLen&nbsp;=&nbsp;USM_AUTH_KU_LEN;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='161'>161</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;/*&nbsp;set&nbsp;the&nbsp;authentication&nbsp;key&nbsp;to&nbsp;a&nbsp;hashed&nbsp;version&nbsp;of&nbsp;our</td>
</tr>
<tr class="noCover">
<td class="line"><a name='162'>162</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;passphrase&nbsp;(which&nbsp;must&nbsp;be&nbsp;at&nbsp;least&nbsp;8&nbsp;characters&nbsp;long)&nbsp;*/</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='163'>163</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(generate_Ku(session-&gt;securityAuthProto,&nbsp;session-&gt;securityAuthProtoLen,&nbsp;(u_char&nbsp;*)trcv-&gt;sAuthPass,</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='164'>164</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;strlen(trcv-&gt;sAuthPass),&nbsp;session-&gt;securityAuthKey,&nbsp;&amp;session-&gt;securityAuthKeyLen)&nbsp;!=&nbsp;SNMPERR_SUCCESS)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='165'>165</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;snmp_log(LOG_ERR,&nbsp;"Error&nbsp;generating&nbsp;Ku&nbsp;from&nbsp;authentication&nbsp;pass&nbsp;phrase.&nbsp;\n");</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='166'>166</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;ret&nbsp;=&nbsp;WAGOSNMP_RETURN_AUTH_ERR;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='167'>167</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='168'>168</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;//&nbsp;set&nbsp;the&nbsp;Privacy&nbsp;variables</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='169'>169</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(session-&gt;securityLevel&nbsp;==&nbsp;SNMP_SEC_LEVEL_AUTHPRIV)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='170'>170</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;switch&nbsp;(trcv-&gt;typPrivProt)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='171'>171</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;WAGOSNMP_PRIV_P_NONE:</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='172'>172</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;session-&gt;securityPrivProto&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;usmNoPrivProtocol;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='173'>173</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;session-&gt;securityPrivProtoLen&nbsp;=&nbsp;sizeof(usmNoPrivProtocol)&nbsp;/&nbsp;sizeof(oid);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='174'>174</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='175'>175</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;WAGOSNMP_PRIV_P_DES:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='176'>176</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/*&nbsp;set&nbsp;the&nbsp;authentication&nbsp;method&nbsp;to&nbsp;MD5&nbsp;*/</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='177'>177</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;session-&gt;securityPrivProto&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;usmDESPrivProtocol;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='178'>178</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;session-&gt;securityPrivProtoLen&nbsp;=&nbsp;sizeof(usmDESPrivProtocol)&nbsp;/&nbsp;sizeof(oid);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='179'>179</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='180'>180</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;WAGOSNMP_PRIV_P_AES:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='181'>181</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/*&nbsp;set&nbsp;the&nbsp;authentication&nbsp;method&nbsp;to&nbsp;MD5&nbsp;*/</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='182'>182</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;session-&gt;securityPrivProto&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;usmAESPrivProtocol;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='183'>183</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;session-&gt;securityPrivProtoLen&nbsp;=&nbsp;sizeof(usmAESPrivProtocol)&nbsp;/&nbsp;sizeof(oid);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='184'>184</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='185'>185</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;default:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='186'>186</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;waht&nbsp;to&nbsp;do&nbsp;in&nbsp;case&nbsp;of&nbsp;error??</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='187'>187</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='188'>188</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='189'>189</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;session-&gt;securityPrivKeyLen&nbsp;=&nbsp;USM_PRIV_KU_LEN;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='190'>190</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;/*&nbsp;set&nbsp;the&nbsp;privacy&nbsp;key&nbsp;to&nbsp;a&nbsp;hashed&nbsp;version&nbsp;of&nbsp;our</td>
</tr>
<tr class="noCover">
<td class="line"><a name='191'>191</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;passphrase&nbsp;(which&nbsp;must&nbsp;be&nbsp;at&nbsp;least&nbsp;8&nbsp;characters&nbsp;long)&nbsp;*/</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='192'>192</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(generate_Ku(session-&gt;securityAuthProto,&nbsp;session-&gt;securityAuthProtoLen,&nbsp;(u_char&nbsp;*)trcv-&gt;sPrivPass,</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='193'>193</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;strlen(trcv-&gt;sPrivPass),&nbsp;session-&gt;securityPrivKey,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='194'>194</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&amp;session-&gt;securityPrivKeyLen)&nbsp;!=&nbsp;SNMPERR_SUCCESS)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='195'>195</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;snmp_log(LOG_ERR,&nbsp;"Error&nbsp;generating&nbsp;Ku&nbsp;from&nbsp;privacy&nbsp;pass&nbsp;phrase.&nbsp;\n");</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='196'>196</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ret&nbsp;=&nbsp;WAGOSNMP_RETURN_PRIV_ERR;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='197'>197</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='198'>198</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='199'>199</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;ret;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='200'>200</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='201'>201</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='202'>202</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;int&nbsp;INTERNAL_SnmpInput(int&nbsp;operation,&nbsp;netsnmp_session&nbsp;*session,&nbsp;int&nbsp;reqid,&nbsp;netsnmp_pdu&nbsp;*pdu,&nbsp;void&nbsp;*magic)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='203'>203</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;1;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='204'>204</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='205'>205</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='206'>206</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;void&nbsp;INTERNAL_InitSnmp(void)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='207'>207</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;init_snmp("snmpapp");</td>
</tr>
<tr class="noCover">
<td class="line"><a name='208'>208</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='209'>209</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='210'>210</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;void&nbsp;INTERNAL_ResetSnmpAgent()&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='211'>211</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;//&nbsp;INIT_SNMP_ONCE;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='212'>212</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;INTERNAL_SendReleaseOIDs();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='213'>213</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;AGENT_DestroyShm();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='214'>214</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;AGENT_DestroyMutex();</td>
</tr>
<tr class="noCover">
<td class="line"><a name='215'>215</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='216'>216</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;void&nbsp;INTERNAL_InitSnmpAgent()&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='217'>217</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;//&nbsp;INIT_SNMP_ONCE;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='218'>218</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;INTERNAL_ResetSnmpAgent();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='219'>219</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;AGENT_CreateMutex();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='220'>220</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;AGENT_CreateShm();</td>
</tr>
<tr class="noCover">
<td class="line"><a name='221'>221</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='222'>222</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='223'>223</a></td>
<td class="hits"></td>
<td class="code">//--&nbsp;Function:&nbsp;_ReTwist&nbsp;---------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='224'>224</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='225'>225</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;The&nbsp;SNMP-API&nbsp;uses&nbsp;two&nbsp;ways&nbsp;to&nbsp;buffer&nbsp;data.</td>
</tr>
<tr class="noCover">
<td class="line"><a name='226'>226</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;1.&nbsp;a&nbsp;40&nbsp;Byte&nbsp;array&nbsp;from&nbsp;inside&nbsp;the&nbsp;netsnmp_variable_list&nbsp;structure</td>
</tr>
<tr class="noCover">
<td class="line"><a name='227'>227</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;2.&nbsp;a&nbsp;dynamically&nbsp;allocated&nbsp;array.</td>
</tr>
<tr class="noCover">
<td class="line"><a name='228'>228</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;the&nbsp;library&nbsp;copys&nbsp;the&nbsp;nvl&nbsp;instancy.&nbsp;after&nbsp;a&nbsp;copy&nbsp;the&nbsp;val&nbsp;pointer&nbsp;my&nbsp;point</td>
</tr>
<tr class="noCover">
<td class="line"><a name='229'>229</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;to&nbsp;the&nbsp;40&nbsp;byte&nbsp;buffe&nbsp;of&nbsp;another&nbsp;(no&nbsp;longer&nbsp;existing)&nbsp;instancy.&nbsp;this&nbsp;can</td>
</tr>
<tr class="noCover">
<td class="line"><a name='230'>230</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;in&nbsp;memory&nbsp;exceptions.</td>
</tr>
<tr class="noCover">
<td class="line"><a name='231'>231</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;This&nbsp;Function&nbsp;hlps&nbsp;to&nbsp;reoder&nbsp;the&nbsp;internla&nbsp;used&nbsp;instancys&nbsp;of&nbsp;nvl&nbsp;which&nbsp;was</td>
</tr>
<tr class="noCover">
<td class="line"><a name='232'>232</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;correted&nbsp;before.</td>
</tr>
<tr class="noCover">
<td class="line"><a name='233'>233</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='234'>234</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;\param&nbsp;stData:&nbsp;&nbsp;Instancy&nbsp;of&nbsp;nvl&nbsp;to&nbsp;be&nbsp;reordered;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='235'>235</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='236'>236</a></td>
<td class="hits"></td>
<td class="code">//-------------------------------------------------------------------------</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='237'>237</a></td>
<td class="hits">6</td>
<td class="code">INTERNAL_SYM&nbsp;void&nbsp;INTERNAL_ReTwist(netsnmp_variable_list&nbsp;*stData)&nbsp;{</td>
</tr>
<tr class="coverPart" title="Line 238: Conditional coverage 50% (1/2)">
<td class="line"><a name='238'>238</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(stData-&gt;val.string&nbsp;==&nbsp;NULL)&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='239'>239</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stData-&gt;val.string&nbsp;=&nbsp;stData-&gt;buf;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='240'>240</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='241'>241</a></td>
<td class="hits">6</td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='242'>242</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverFull">
<td class="line"><a name='243'>243</a></td>
<td class="hits">4</td>
<td class="code">INTERNAL_SYM&nbsp;int&nbsp;INTERNAL_SetVarTypedValue(netsnmp_variable_list&nbsp;*stData,&nbsp;u_char&nbsp;eType,&nbsp;u_char&nbsp;*input,&nbsp;size_t&nbsp;size)&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='244'>244</a></td>
<td class="hits"></td>
<td class="code">#if&nbsp;USE_OWN_COPY_FUNCTION</td>
</tr>
<tr class="noCover">
<td class="line"><a name='245'>245</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;if&nbsp;(stData-&gt;next_variable&nbsp;!=&nbsp;NULL)&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='246'>246</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;netsnmp_variable_list&nbsp;*pNext&nbsp;=&nbsp;stData-&gt;next_variable;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='247'>247</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(pNext-&gt;buf&nbsp;!=&nbsp;pNext-&gt;val.string)&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='248'>248</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;pNext-&gt;val.string&nbsp;=&nbsp;NULL;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='249'>249</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='250'>250</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stData-&gt;next_variable&nbsp;=&nbsp;NULL;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='251'>251</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='252'>252</a></td>
<td class="hits"></td>
<td class="code">#endif</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='253'>253</a></td>
<td class="hits">4</td>
<td class="code">&nbsp;&nbsp;return&nbsp;snmp_set_var_typed_value(stData,&nbsp;(u_char)eType,&nbsp;input,&nbsp;size);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='254'>254</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='255'>255</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='256'>256</a></td>
<td class="hits"></td>
<td class="code">//--&nbsp;Function:&nbsp;_DeTwist&nbsp;---------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='257'>257</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='258'>258</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;The&nbsp;SNMP-API&nbsp;uses&nbsp;two&nbsp;ways&nbsp;to&nbsp;buffer&nbsp;data.</td>
</tr>
<tr class="noCover">
<td class="line"><a name='259'>259</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;1.&nbsp;a&nbsp;40&nbsp;Byte&nbsp;array&nbsp;from&nbsp;inside&nbsp;the&nbsp;netsnmp_variable_list&nbsp;structure</td>
</tr>
<tr class="noCover">
<td class="line"><a name='260'>260</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;2.&nbsp;a&nbsp;dynamically&nbsp;allocated&nbsp;array.</td>
</tr>
<tr class="noCover">
<td class="line"><a name='261'>261</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;the&nbsp;library&nbsp;copys&nbsp;the&nbsp;nvl&nbsp;instancy.&nbsp;after&nbsp;a&nbsp;copy&nbsp;the&nbsp;val&nbsp;pointer&nbsp;my&nbsp;point</td>
</tr>
<tr class="noCover">
<td class="line"><a name='262'>262</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;to&nbsp;the&nbsp;40&nbsp;byte&nbsp;buffe&nbsp;of&nbsp;another&nbsp;(no&nbsp;longer&nbsp;existing)&nbsp;instancy.&nbsp;this&nbsp;can</td>
</tr>
<tr class="noCover">
<td class="line"><a name='263'>263</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;in&nbsp;memory&nbsp;exceptions.</td>
</tr>
<tr class="noCover">
<td class="line"><a name='264'>264</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;this&nbsp;Function&nbsp;sets&nbsp;the&nbsp;pointer&nbsp;which&nbsp;target&nbsp;to&nbsp;the&nbsp;value&nbsp;to&nbsp;NULL&nbsp;in&nbsp;case&nbsp;of</td>
</tr>
<tr class="noCover">
<td class="line"><a name='265'>265</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;using&nbsp;the&nbsp;internal&nbsp;Buffer</td>
</tr>
<tr class="noCover">
<td class="line"><a name='266'>266</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='267'>267</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;\param&nbsp;stData:&nbsp;&nbsp;Instancy&nbsp;of&nbsp;nvl&nbsp;to&nbsp;be&nbsp;reordered;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='268'>268</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='269'>269</a></td>
<td class="hits"></td>
<td class="code">//-------------------------------------------------------------------------</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='270'>270</a></td>
<td class="hits">6</td>
<td class="code">INTERNAL_SYM&nbsp;void&nbsp;INTERNAL_DeTwist(netsnmp_variable_list&nbsp;*stData)&nbsp;{</td>
</tr>
<tr class="coverPart" title="Line 271: Conditional coverage 50% (1/2)">
<td class="line"><a name='271'>271</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(stData-&gt;val.string&nbsp;==&nbsp;stData-&gt;buf)&nbsp;{</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='272'>272</a></td>
<td class="hits">6</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;stData-&gt;val.string&nbsp;=&nbsp;NULL;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='273'>273</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverFull">
<td class="line"><a name='274'>274</a></td>
<td class="hits">6</td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='275'>275</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='276'>276</a></td>
<td class="hits"></td>
<td class="code">//--&nbsp;Function:&nbsp;_SnprintValue&nbsp;-----------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='277'>277</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='278'>278</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;Copy/Paste&nbsp;from&nbsp;snmp-&gt;&nbsp;snmplib/mib.c&nbsp;snprint_value</td>
</tr>
<tr class="noCover">
<td class="line"><a name='279'>279</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;Only&nbsp;a&nbsp;Wrapper&nbsp;for&nbsp;_SprintReallocValue&nbsp;to&nbsp;be&nbsp;equal&nbsp;to&nbsp;the&nbsp;snprin_value&nbsp;way</td>
</tr>
<tr class="noCover">
<td class="line"><a name='280'>280</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='281'>281</a></td>
<td class="hits"></td>
<td class="code">//-----------------------------------------------------------------------------</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='282'>282</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;int&nbsp;INTERNAL_SnprintValue(char&nbsp;*buf,&nbsp;size_t&nbsp;buf_len,&nbsp;const&nbsp;oid&nbsp;*objid,&nbsp;size_t&nbsp;objidlen,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='283'>283</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;const&nbsp;netsnmp_variable_list&nbsp;*variable)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='284'>284</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;size_t&nbsp;out_len&nbsp;=&nbsp;0;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='285'>285</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='286'>286</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(_SprintReallocValue((u_char&nbsp;**)&amp;buf,&nbsp;&amp;buf_len,&nbsp;&amp;out_len,&nbsp;0,&nbsp;objid,&nbsp;objidlen,&nbsp;variable))&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='287'>287</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;(int)out_len;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='288'>288</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}&nbsp;else&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='289'>289</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;-1;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='290'>290</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='291'>291</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='292'>292</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='293'>293</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;char&nbsp;*INTERNAL_StripQuotes(char&nbsp;*p)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='294'>294</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(*p&nbsp;==&nbsp;'\"'&nbsp;&amp;&amp;&nbsp;p[strlen(p)&nbsp;-&nbsp;1]&nbsp;==&nbsp;'\"')&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='295'>295</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;p++;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='296'>296</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;p[strlen(p)&nbsp;-&nbsp;1]&nbsp;=&nbsp;0;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='297'>297</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='298'>298</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;p;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='299'>299</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='300'>300</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='301'>301</a></td>
<td class="hits"></td>
<td class="code">//--&nbsp;Function:&nbsp;_GetSnmpSession&nbsp;-------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='302'>302</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='303'>303</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;Initiate&nbsp;the&nbsp;new&nbsp;SNMP-Session&nbsp;for&nbsp;all&nbsp;Protocol&nbsp;Versions</td>
</tr>
<tr class="noCover">
<td class="line"><a name='304'>304</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='305'>305</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;\param&nbsp;msg:&nbsp;Pointer&nbsp;to&nbsp;the&nbsp;actual&nbsp;used&nbsp;Message</td>
</tr>
<tr class="noCover">
<td class="line"><a name='306'>306</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;\param&nbsp;ss:&nbsp;&nbsp;Pointer&nbsp;to&nbsp;the&nbsp;newly&nbsp;created&nbsp;session-poiner</td>
</tr>
<tr class="noCover">
<td class="line"><a name='307'>307</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='308'>308</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='309'>309</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;tWagoSnmpReturnCode&nbsp;INTERNAL_GetSnmpSession(tWagoSnmpTranceiver&nbsp;*trcv,&nbsp;netsnmp_session&nbsp;**ss)&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='310'>310</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;netsnmp_session&nbsp;tmpss;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='311'>311</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;tWagoSnmpReturnCode&nbsp;ret&nbsp;=&nbsp;WAGOSNMP_RETURN_OK;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='312'>312</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='313'>313</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;INIT_SNMP_ONCE;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='314'>314</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;snmp_sess_init(&amp;tmpss);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='315'>315</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;tmpss.version&nbsp;=&nbsp;trcv-&gt;version;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='316'>316</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;tmpss.retries&nbsp;=&nbsp;trcv-&gt;retries;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='317'>317</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;tmpss.timeout&nbsp;=&nbsp;trcv-&gt;timeout_us;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='318'>318</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(trcv-&gt;sHost[0]&nbsp;!=&nbsp;0)&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='319'>319</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;tmpss.peername&nbsp;=&nbsp;strdup(msg-&gt;trcvData.sHost);//warum&nbsp;hier&nbsp;strdup&nbsp;und&nbsp;oben&nbsp;nicht?</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='320'>320</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;tmpss.peername&nbsp;=&nbsp;trcv-&gt;sHost;&nbsp;&nbsp;//&nbsp;ich&nbsp;sehe&nbsp;nicht&nbsp;warum&nbsp;das&nbsp;nihct&nbsp;gehen&nbsp;sollte</td>
</tr>
<tr class="noCover">
<td class="line"><a name='321'>321</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='322'>322</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='323'>323</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;((trcv-&gt;version&nbsp;==&nbsp;SNMP_VERSION_1)&nbsp;||&nbsp;(trcv-&gt;version&nbsp;==&nbsp;SNMP_VERSION_2c))&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='324'>324</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;/*&nbsp;set&nbsp;the&nbsp;SNMPv1&nbsp;community&nbsp;name&nbsp;used&nbsp;for&nbsp;authentication&nbsp;*/</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='325'>325</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;tmpss.community&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;(u_char&nbsp;*)trcv-&gt;sCommunity;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='326'>326</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;tmpss.community_len&nbsp;=&nbsp;strlen((char&nbsp;*)tmpss.community);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='327'>327</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}&nbsp;else&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='328'>328</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;/*&nbsp;set&nbsp;the&nbsp;SNMPv3&nbsp;user&nbsp;name&nbsp;*/</td>
</tr>
<tr class="noCover">
<td class="line"><a name='329'>329</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;tmpss.securityName&nbsp;=&nbsp;strdup(msg-&gt;trcvData.sUsername);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='330'>330</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;tmpss.securityName&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;trcv-&gt;sUsername;&nbsp;&nbsp;//&nbsp;s.o.</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='331'>331</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;tmpss.securityNameLen&nbsp;=&nbsp;strlen(tmpss.securityName);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='332'>332</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='333'>333</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;/*&nbsp;set&nbsp;the&nbsp;security&nbsp;level&nbsp;to&nbsp;authenticated,&nbsp;but&nbsp;not&nbsp;encrypted&nbsp;*/</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='334'>334</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;tmpss.securityLevel&nbsp;=&nbsp;trcv-&gt;typSecLevel;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='335'>335</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;ret&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;INTERNAL_SetAuthPriv(trcv,&nbsp;&amp;tmpss);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='336'>336</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='337'>337</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(trcv-&gt;trcvType&nbsp;==&nbsp;WAGOSNMP_TRCV_INFORM)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='338'>338</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;tmpss.callback&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;INTERNAL_SnmpInput;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='339'>339</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;tmpss.callback_magic&nbsp;=&nbsp;NULL;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='340'>340</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;setup_engineID(NULL,&nbsp;NULL);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='341'>341</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(tmpss.contextEngineIDLen&nbsp;==&nbsp;0&nbsp;||&nbsp;tmpss.contextEngineID&nbsp;==&nbsp;NULL)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='342'>342</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;tmpss.contextEngineID&nbsp;=&nbsp;snmpv3_generate_engineID(&amp;tmpss.contextEngineIDLen);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='343'>343</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='344'>344</a></td>
<td class="hits"></td>
<td class="code">#if&nbsp;1</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='345'>345</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(tmpss.version&nbsp;==&nbsp;SNMP_VERSION_3&nbsp;&amp;&amp;&nbsp;trcv-&gt;sEngineId&nbsp;!=&nbsp;NULL&nbsp;&amp;&amp;&nbsp;trcv-&gt;sEngineId[0]&nbsp;!=&nbsp;0)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='346'>346</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;size_t&nbsp;ebuf_len&nbsp;=&nbsp;32,&nbsp;eout_len&nbsp;=&nbsp;0;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='347'>347</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;u_char&nbsp;*ebuf&nbsp;=&nbsp;(u_char&nbsp;*)malloc(ebuf_len);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='348'>348</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='349'>349</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(!snmp_hex_to_binary(&amp;ebuf,&nbsp;&amp;ebuf_len,&nbsp;&amp;eout_len,&nbsp;1,&nbsp;trcv-&gt;sEngineId))&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='350'>350</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;fprintf(stderr,&nbsp;"Bad&nbsp;engine&nbsp;ID&nbsp;value.\n");</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='351'>351</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;free(ebuf);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='352'>352</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ret&nbsp;=&nbsp;WAGOSNMP_RETURN_ERROR_BAD_ENGINE_ID;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='353'>353</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='354'>354</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;((eout_len&nbsp;&lt;&nbsp;5)&nbsp;||&nbsp;(eout_len&nbsp;&gt;&nbsp;32))&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='355'>355</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;fprintf(stderr,&nbsp;"Invalid&nbsp;engine&nbsp;ID&nbsp;value\n");</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='356'>356</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;free(ebuf);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='357'>357</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ret&nbsp;=&nbsp;WAGOSNMP_RETURN_ERROR_INVALID_ENGINE_ID;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='358'>358</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='359'>359</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;tmpss.securityEngineID&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;ebuf;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='360'>360</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;tmpss.securityEngineIDLen&nbsp;=&nbsp;eout_len;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='361'>361</a></td>
<td class="hits"></td>
<td class="code">#if&nbsp;0</td>
</tr>
<tr class="noCover">
<td class="line"><a name='362'>362</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(&nbsp;&nbsp;&nbsp;(tmpss.securityEngineIDLen&nbsp;==&nbsp;0)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='363'>363</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;(tmpss.securityEngineID&nbsp;==&nbsp;NULL))</td>
</tr>
<tr class="noCover">
<td class="line"><a name='364'>364</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='365'>365</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;tmpss.securityEngineID&nbsp;=&nbsp;snmpv3_generate_engineID(&amp;tmpss.securityEngineIDLen);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='366'>366</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='367'>367</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='368'>368</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/*</td>
</tr>
<tr class="noCover">
<td class="line"><a name='369'>369</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;set&nbsp;boots&nbsp;and&nbsp;time,&nbsp;which&nbsp;will&nbsp;cause&nbsp;problems&nbsp;if&nbsp;this</td>
</tr>
<tr class="noCover">
<td class="line"><a name='370'>370</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;machine&nbsp;ever&nbsp;reboots&nbsp;and&nbsp;a&nbsp;remote&nbsp;trap&nbsp;receiver&nbsp;has&nbsp;cached&nbsp;our</td>
</tr>
<tr class="noCover">
<td class="line"><a name='371'>371</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;boots&nbsp;and&nbsp;time...&nbsp;&nbsp;I'll&nbsp;cause&nbsp;a&nbsp;not-in-time-window&nbsp;report&nbsp;to</td>
</tr>
<tr class="noCover">
<td class="line"><a name='372'>372</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;be&nbsp;sent&nbsp;back&nbsp;to&nbsp;this&nbsp;machine.</td>
</tr>
<tr class="noCover">
<td class="line"><a name='373'>373</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*/</td>
</tr>
<tr class="noCover">
<td class="line"><a name='374'>374</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(tmpss.engineBoots&nbsp;==&nbsp;0)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='375'>375</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;tmpss.engineBoots&nbsp;=&nbsp;1;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='376'>376</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(tmpss.engineTime&nbsp;==&nbsp;0)&nbsp;&nbsp;&nbsp;&nbsp;/*&nbsp;not&nbsp;really&nbsp;correct,&nbsp;*/</td>
</tr>
<tr class="noCover">
<td class="line"><a name='377'>377</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;tmpss.engineTime&nbsp;=&nbsp;get_uptime();&nbsp;&nbsp;/*&nbsp;but&nbsp;it'll&nbsp;work.&nbsp;Sort&nbsp;of.&nbsp;*/</td>
</tr>
<tr class="noCover">
<td class="line"><a name='378'>378</a></td>
<td class="hits"></td>
<td class="code">#endif</td>
</tr>
<tr class="noCover">
<td class="line"><a name='379'>379</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='380'>380</a></td>
<td class="hits"></td>
<td class="code">#endif</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='381'>381</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(ret&nbsp;==&nbsp;WAGOSNMP_RETURN_OK)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='382'>382</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;netsnmp_transport&nbsp;*transport&nbsp;=&nbsp;netsnmp_transport_open_client("snmptrap",&nbsp;tmpss.peername);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='383'>383</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*ss&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;snmp_add(&amp;tmpss,&nbsp;transport,&nbsp;NULL,&nbsp;NULL);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='384'>384</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='385'>385</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}&nbsp;else&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='386'>386</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(ret&nbsp;==&nbsp;WAGOSNMP_RETURN_OK)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='387'>387</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*ss&nbsp;=&nbsp;snmp_open(&amp;tmpss);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='388'>388</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='389'>389</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='390'>390</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(!*ss)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='391'>391</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;snmp_sess_perror("snmp&nbsp;session&nbsp;error",&nbsp;&amp;tmpss);&nbsp;&nbsp;//&nbsp;this&nbsp;function&nbsp;is&nbsp;badly&nbsp;described!!!</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='392'>392</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(ret&nbsp;==&nbsp;WAGOSNMP_RETURN_OK)&nbsp;ret&nbsp;=&nbsp;WAGOSNMP_RETURN_INIT_SESSION_ERROR;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='393'>393</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='394'>394</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;ret;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='395'>395</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='396'>396</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='397'>397</a></td>
<td class="hits"></td>
<td class="code">//--&nbsp;Function:&nbsp;_GetSnmpSession&nbsp;-------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='398'>398</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='399'>399</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;Create&nbsp;the&nbsp;PDU&nbsp;for&nbsp;the&nbsp;transcieve!</td>
</tr>
<tr class="noCover">
<td class="line"><a name='400'>400</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='401'>401</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;\param&nbsp;msg:&nbsp;Pointer&nbsp;to&nbsp;the&nbsp;actual&nbsp;used&nbsp;Message</td>
</tr>
<tr class="noCover">
<td class="line"><a name='402'>402</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;\param&nbsp;pdu:&nbsp;&nbsp;Pointer&nbsp;to&nbsp;the&nbsp;newly&nbsp;created&nbsp;pdu-poiner</td>
</tr>
<tr class="noCover">
<td class="line"><a name='403'>403</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='404'>404</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='405'>405</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;int&nbsp;INTERNAL_GetSnmpPdu(tWagoSnmpTranceiver&nbsp;*trcv,&nbsp;netsnmp_pdu&nbsp;**pdu)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='406'>406</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;int&nbsp;type&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;0;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='407'>407</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;size_t&nbsp;anOID_len&nbsp;=&nbsp;MAX_OID_LEN;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='408'>408</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;oid&nbsp;anOID[MAX_OID_LEN];</td>
</tr>
<tr class="noCover">
<td class="line"><a name='409'>409</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='410'>410</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;((trcv-&gt;trcvType&nbsp;==&nbsp;WAGOSNMP_TRCV_GET))&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='411'>411</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;type&nbsp;=&nbsp;SNMP_MSG_GET;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='412'>412</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;}&nbsp;else&nbsp;if&nbsp;(trcv-&gt;trcvType&nbsp;==&nbsp;WAGOSNMP_TRCV_SET)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='413'>413</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;type&nbsp;=&nbsp;SNMP_MSG_SET;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='414'>414</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;}&nbsp;else&nbsp;if&nbsp;(trcv-&gt;trcvType&nbsp;==&nbsp;WAGOSNMP_TRCV_INFORM)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='415'>415</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;type&nbsp;=&nbsp;SNMP_MSG_INFORM;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='416'>416</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}&nbsp;else&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='417'>417</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;WAGOSNMP_RETURN_BAD_MSG_TYPE;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='418'>418</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='419'>419</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='420'>420</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(trcv-&gt;sOID&nbsp;!=&nbsp;NULL&nbsp;&amp;&amp;&nbsp;trcv-&gt;sOID[0]&nbsp;!=&nbsp;0)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='421'>421</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;anOID_len&nbsp;=&nbsp;MAX_OID_LEN;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='422'>422</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;SNMP_MutexLock();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='423'>423</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(!snmp_parse_oid(trcv-&gt;sOID,&nbsp;anOID,&nbsp;&amp;anOID_len))&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='424'>424</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SNMP_MutexUnlock();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='425'>425</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;snmp_perror(trcv-&gt;sOID);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='426'>426</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;WAGOSNMP_RETURN_PARSE_OID_ERROR;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='427'>427</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='428'>428</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;SNMP_MutexUnlock();</td>
</tr>
<tr class="noCover">
<td class="line"><a name='429'>429</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}&nbsp;else&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='430'>430</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;WAGOSNMP_RETURN_ERROR_PARAMETER;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='431'>431</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='432'>432</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='433'>433</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;*pdu&nbsp;=&nbsp;snmp_pdu_create(type);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='434'>434</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='435'>435</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(type&nbsp;==&nbsp;SNMP_MSG_GET)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='436'>436</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;snmp_add_null_var(*pdu,&nbsp;anOID,&nbsp;anOID_len);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='437'>437</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;}&nbsp;else&nbsp;if&nbsp;(type&nbsp;==&nbsp;SNMP_MSG_SET&nbsp;||&nbsp;type&nbsp;==&nbsp;SNMP_MSG_INFORM)&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='438'>438</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;u_char&nbsp;*buf;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='439'>439</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='440'>440</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(type&nbsp;==&nbsp;SNMP_MSG_INFORM)&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='441'>441</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;u_long&nbsp;uptime;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='442'>442</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;static&nbsp;const&nbsp;oid&nbsp;objid_sysuptime[]&nbsp;=&nbsp;{1,&nbsp;3,&nbsp;6,&nbsp;1,&nbsp;2,&nbsp;1,&nbsp;1,&nbsp;3,&nbsp;0};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='443'>443</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;static&nbsp;const&nbsp;oid&nbsp;objid_snmptrap[]&nbsp;&nbsp;=&nbsp;{1,&nbsp;3,&nbsp;6,&nbsp;1,&nbsp;6,&nbsp;3,&nbsp;1,&nbsp;1,&nbsp;4,&nbsp;1,&nbsp;0};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='444'>444</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='445'>445</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;If&nbsp;additional&nbsp;OID&nbsp;is&nbsp;given&nbsp;but&nbsp;tlv&nbsp;is&nbsp;uninitialized&nbsp;return&nbsp;error!</td>
</tr>
<tr class="noCover">
<td class="line"><a name='446'>446</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;uninitializes&nbsp;will&nbsp;be&nbsp;recocnised&nbsp;ny&nbsp;type&nbsp;==&nbsp;0</td>
</tr>
<tr class="noCover">
<td class="line"><a name='447'>447</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;type&nbsp;==&nbsp;0&nbsp;is&nbsp;ASN&nbsp;UNIVERSAL&nbsp;but&nbsp;actually&nbsp;this&nbsp;will&nbsp;not&nbsp;be&nbsp;used</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='448'>448</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(((trcv-&gt;sInformOID&nbsp;==&nbsp;NULL&nbsp;||&nbsp;trcv-&gt;sInformOID[0]&nbsp;==&nbsp;0)&nbsp;&amp;&amp;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='449'>449</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(SNMP_TLV_INITALIZED(trcv-&gt;typData)&nbsp;&amp;&amp;&nbsp;!SNMP_TLV_IS_NULL(trcv-&gt;typData)))&nbsp;||</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='450'>450</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;((trcv-&gt;sInformOID&nbsp;!=&nbsp;NULL&nbsp;&amp;&amp;&nbsp;trcv-&gt;sInformOID[0]&nbsp;!=&nbsp;0)&nbsp;&amp;&amp;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='451'>451</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(!SNMP_TLV_INITALIZED(trcv-&gt;typData)&nbsp;||&nbsp;SNMP_TLV_IS_NULL(trcv-&gt;typData))))&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='452'>452</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;snmp_free_pdu(*pdu);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='453'>453</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;WAGOSNMP_RETURN_ERROR_PARAMETER;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='454'>454</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='455'>455</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='456'>456</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;uptime&nbsp;=&nbsp;get_uptime();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='457'>457</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(NULL&nbsp;==&nbsp;snmp_pdu_add_variable(*pdu,&nbsp;objid_sysuptime,&nbsp;sizeof(objid_sysuptime)&nbsp;/&nbsp;sizeof(oid),&nbsp;ASN_TIMETICKS,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='458'>458</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&amp;uptime,&nbsp;sizeof(uptime)))&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='459'>459</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;snmp_free_pdu(*pdu);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='460'>460</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;WAGOSNMP_RETURN_ERR_MALLOC;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='461'>461</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='462'>462</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(NULL&nbsp;==&nbsp;snmp_pdu_add_variable(*pdu,&nbsp;objid_snmptrap,&nbsp;sizeof(objid_snmptrap)&nbsp;/&nbsp;sizeof(oid),&nbsp;ASN_OBJECT_ID,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='463'>463</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;anOID,&nbsp;anOID_len&nbsp;*&nbsp;sizeof(oid)))&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='464'>464</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;snmp_free_pdu(*pdu);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='465'>465</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;WAGOSNMP_RETURN_ERR_MALLOC;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='466'>466</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='467'>467</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;get&nbsp;InformOID&nbsp;into&nbsp;the&nbsp;anOID&nbsp;buffer&nbsp;for&nbsp;the&nbsp;additional&nbsp;OID</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='468'>468</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;anOID_len&nbsp;=&nbsp;MAX_OID_LEN;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='469'>469</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SNMP_MutexLock();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='470'>470</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;((trcv-&gt;sInformOID&nbsp;!=&nbsp;NULL&nbsp;&amp;&amp;&nbsp;trcv-&gt;sInformOID[0]&nbsp;!=&nbsp;0)&nbsp;&amp;&amp;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='471'>471</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(!snmp_parse_oid(trcv-&gt;sInformOID,&nbsp;anOID,&nbsp;&amp;anOID_len)))&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='472'>472</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SNMP_MutexUnlock();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='473'>473</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;snmp_perror(trcv-&gt;sInformOID);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='474'>474</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;snmp_free_pdu(*pdu);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='475'>475</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;WAGOSNMP_RETURN_PARSE_OID_ERROR;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='476'>476</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='477'>477</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SNMP_MutexUnlock();</td>
</tr>
<tr class="noCover">
<td class="line"><a name='478'>478</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='479'>479</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(!SNMP_TLV_IS_NULL(trcv-&gt;typData)&nbsp;&amp;&amp;&nbsp;SNMP_TLV_INITALIZED(trcv-&gt;typData))&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='480'>480</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(SNMP_TLV(trcv-&gt;typData)-&gt;val.string&nbsp;==&nbsp;NULL)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='481'>481</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;buf&nbsp;=&nbsp;SNMP_TLV(trcv-&gt;typData)-&gt;buf;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='482'>482</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}&nbsp;else&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='483'>483</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;buf&nbsp;=&nbsp;SNMP_TLV(trcv-&gt;typData)-&gt;val.string;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='484'>484</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='485'>485</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;snmp_pdu_add_variable(*pdu,&nbsp;anOID,&nbsp;anOID_len,&nbsp;SNMP_TLV(trcv-&gt;typData)-&gt;type,&nbsp;buf,</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='486'>486</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SNMP_TLV(trcv-&gt;typData)-&gt;val_len);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='487'>487</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}&nbsp;else&nbsp;if&nbsp;(type&nbsp;==&nbsp;SNMP_MSG_SET)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='488'>488</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;snmp_free_pdu(*pdu);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='489'>489</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;WAGOSNMP_RETURN_BAD_DATATYPE;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='490'>490</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='491'>491</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}&nbsp;else&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='492'>492</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;snmp_free_pdu(*pdu);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='493'>493</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;WAGOSNMP_RETURN_BAD_MSG_TYPE;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='494'>494</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='495'>495</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='496'>496</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;WAGOSNMP_RETURN_OK;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='497'>497</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='498'>498</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='499'>499</a></td>
<td class="hits"></td>
<td class="code">//--&nbsp;Function:&nbsp;_GetSnmpSession&nbsp;-------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='500'>500</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='501'>501</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;Do&nbsp;the&nbsp;transcive&nbsp;action!</td>
</tr>
<tr class="noCover">
<td class="line"><a name='502'>502</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='503'>503</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;\param&nbsp;msg:&nbsp;PLC&nbsp;instancys</td>
</tr>
<tr class="noCover">
<td class="line"><a name='504'>504</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;\param&nbsp;pdu:&nbsp;instancy&nbsp;that&nbsp;(will)&nbsp;hold&nbsp;the&nbsp;OID&nbsp;Infomation&nbsp;Structures</td>
</tr>
<tr class="noCover">
<td class="line"><a name='505'>505</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;\param&nbsp;ss:&nbsp;&nbsp;session&nbsp;Pointer</td>
</tr>
<tr class="noCover">
<td class="line"><a name='506'>506</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='507'>507</a></td>
<td class="hits"></td>
<td class="code">//-----------------------------------------------------------------------------</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='508'>508</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;int&nbsp;INTERNAL_Tranceive(tWagoSnmpTranceiver&nbsp;*trcv,&nbsp;netsnmp_pdu&nbsp;*pdu,&nbsp;netsnmp_session&nbsp;*ss)&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='509'>509</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;int&nbsp;status;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='510'>510</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;int&nbsp;ret&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;WAGOSNMP_RETURN_OK;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='511'>511</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;netsnmp_pdu&nbsp;*response&nbsp;=&nbsp;NULL;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='512'>512</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='513'>513</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;status&nbsp;=&nbsp;snmp_synch_response(ss,&nbsp;pdu,&nbsp;&amp;response);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='514'>514</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='515'>515</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(status&nbsp;==&nbsp;STAT_SUCCESS&nbsp;&amp;&amp;&nbsp;response-&gt;errstat&nbsp;==&nbsp;SNMP_ERR_NOERROR)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='516'>516</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(trcv-&gt;trcvType&nbsp;==&nbsp;WAGOSNMP_TRCV_GET)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='517'>517</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_CopySnmpVarData(trcv,&nbsp;response-&gt;variables);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='518'>518</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='519'>519</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}&nbsp;else&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='520'>520</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(status&nbsp;==&nbsp;STAT_SUCCESS)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='521'>521</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;fprintf(stderr,&nbsp;"Error&nbsp;in&nbsp;packet&nbsp;0x%X,&nbsp;0x%X,&nbsp;%s\nReason:&nbsp;%s\n",&nbsp;trcv-&gt;trcvType,&nbsp;(unsigned&nbsp;int)trcv-&gt;version,</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='522'>522</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;trcv-&gt;sOID,&nbsp;snmp_errstring(response-&gt;errstat));</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='523'>523</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ret&nbsp;=&nbsp;WAGOSNMP_RETURN_PACKAGE_ERROR;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='524'>524</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}&nbsp;else&nbsp;if&nbsp;(status&nbsp;==&nbsp;STAT_TIMEOUT)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='525'>525</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;fprintf(stderr,&nbsp;"Timeout:&nbsp;No&nbsp;response&nbsp;from&nbsp;%s.\n",&nbsp;trcv-&gt;sHost);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='526'>526</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ret&nbsp;=&nbsp;WAGOSNMP_RETURN_TIMEOUT;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='527'>527</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}&nbsp;else&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='528'>528</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;snmp_sess_perror("plcsnmp_manager",&nbsp;ss);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='529'>529</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ret&nbsp;=&nbsp;WAGOSNMP_RETURN_TRANSCEIVE_ERROR;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='530'>530</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='531'>531</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='532'>532</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(response)&nbsp;snmp_free_pdu(response);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='533'>533</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;SNMP_MutexLock();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='534'>534</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;snmp_close(ss);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='535'>535</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;//&nbsp;shutdown&nbsp;the&nbsp;app&nbsp;and&nbsp;set&nbsp;reinit&nbsp;flag&nbsp;correctly</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='536'>536</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;snmp_shutdown("snmpapp");</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='537'>537</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;snmp_is_initialized&nbsp;=&nbsp;PTHREAD_ONCE_INIT;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='538'>538</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;SNMP_MutexUnlock();</td>
</tr>
<tr class="noCover">
<td class="line"><a name='539'>539</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='540'>540</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;ret;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='541'>541</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='542'>542</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='543'>543</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;int&nbsp;INTERNAL_ConvertTlvToTrapVar(tTrapVariableType&nbsp;*var,&nbsp;netsnmp_variable_list&nbsp;*stData)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='544'>544</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;int&nbsp;ret&nbsp;=&nbsp;WAGOSNMP_RETURN_OK;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='545'>545</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;INTERNAL_ReTwist(stData);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='546'>546</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;switch&nbsp;(stData-&gt;type)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='547'>547</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;ASN_INTEGER:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='548'>548</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;ASN_TIMETICKS:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='549'>549</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;ASN_COUNTER:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='550'>550</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;ASN_UNSIGNED:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='551'>551</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;ASN_UINTEGER:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='552'>552</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;ASN_COUNTER64:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='553'>553</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;ASN_OPAQUE_FLOAT:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='554'>554</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;ASN_OPAQUE_DOUBLE:</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='555'>555</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;memcpy(var-&gt;buf,&nbsp;stData-&gt;val.integer,&nbsp;stData-&gt;val_len);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='556'>556</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='557'>557</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;ASN_OBJECT_ID:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='558'>558</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;ASN_PRIV_IMPLIED_OBJECT_ID:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='559'>559</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;ASN_PRIV_INCL_RANGE:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='560'>560</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;ASN_PRIV_EXCL_RANGE:</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='561'>561</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;memcpy(var-&gt;buf,&nbsp;stData-&gt;val.objid,&nbsp;stData-&gt;val_len);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='562'>562</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='563'>563</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;ASN_IPADDRESS:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='564'>564</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;ASN_PRIV_IMPLIED_OCTET_STR:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='565'>565</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;ASN_OCTET_STR:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='566'>566</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;ASN_BIT_STR:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='567'>567</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;ASN_OPAQUE:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='568'>568</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;ASN_NSAP:</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='569'>569</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;memcpy(var-&gt;buf,&nbsp;stData-&gt;val.string,&nbsp;stData-&gt;val_len);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='570'>570</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='571'>571</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;default:</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='572'>572</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ret&nbsp;=&nbsp;WAGOSNMP_RETURN_BAD_DATATYPE;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='573'>573</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='574'>574</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='575'>575</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;var-&gt;type&nbsp;=&nbsp;stData-&gt;type;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='576'>576</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;var-&gt;len&nbsp;&nbsp;=&nbsp;stData-&gt;val_len;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='577'>577</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;INTERNAL_DeTwist(stData);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='578'>578</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;ret;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='579'>579</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='580'>580</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='581'>581</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;int&nbsp;INTERNAL_SendTrapMsg(tWagoSnmpMsg&nbsp;*msg)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='582'>582</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;int&nbsp;ret&nbsp;=&nbsp;1;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='583'>583</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;struct&nbsp;pollfd&nbsp;fdsnd;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='584'>584</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;mqd_t&nbsp;mq;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='585'>585</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='586'>586</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;mq&nbsp;=&nbsp;_OpenClientQueue(TRAP_AGENT_MQ,&nbsp;sizeof(tWagoSnmpMsg),&nbsp;1);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='587'>587</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(mq&nbsp;&gt;=&nbsp;0)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='588'>588</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;fdsnd.fd&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;mq;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='589'>589</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;fdsnd.events&nbsp;&nbsp;=&nbsp;POLLOUT;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='590'>590</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;fdsnd.revents&nbsp;=&nbsp;0;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='591'>591</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(0&nbsp;&lt;&nbsp;poll(&amp;fdsnd,&nbsp;1,&nbsp;-1))&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='592'>592</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ret&nbsp;=&nbsp;mq_send(mq,&nbsp;(const&nbsp;char&nbsp;*)msg,&nbsp;sizeof(tWagoSnmpMsg),&nbsp;0);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='593'>593</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='594'>594</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;mq_close(mq);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='595'>595</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='596'>596</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;ret;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='597'>597</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='598'>598</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='599'>599</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;int&nbsp;INTERNAL_SendReleaseOIDs(void)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='600'>600</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;int&nbsp;ret&nbsp;=&nbsp;1;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='601'>601</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;struct&nbsp;pollfd&nbsp;fdsnd;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='602'>602</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;mqd_t&nbsp;mq;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='603'>603</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;tWagoSnmpMsg&nbsp;msg;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='604'>604</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;msg.type&nbsp;=&nbsp;MSG_TYPE_RESET;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='605'>605</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='606'>606</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;mq&nbsp;=&nbsp;_OpenClientQueue(TRAP_AGENT_MQ,&nbsp;sizeof(tWagoSnmpMsg),&nbsp;1);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='607'>607</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(mq&nbsp;&gt;=&nbsp;0)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='608'>608</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;fdsnd.fd&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;mq;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='609'>609</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;fdsnd.events&nbsp;&nbsp;=&nbsp;POLLOUT;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='610'>610</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;fdsnd.revents&nbsp;=&nbsp;0;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='611'>611</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(0&nbsp;&lt;&nbsp;poll(&amp;fdsnd,&nbsp;1,&nbsp;-1))&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='612'>612</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ret&nbsp;=&nbsp;mq_send(mq,&nbsp;(const&nbsp;char&nbsp;*)&amp;msg,&nbsp;sizeof(tWagoSnmpMsg),&nbsp;0);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='613'>613</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='614'>614</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;mq_close(mq);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='615'>615</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='616'>616</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;ret;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='617'>617</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='618'>618</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='619'>619</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;int&nbsp;INTERNAL_InformForNewOid(tOidObject&nbsp;*object)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='620'>620</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;int&nbsp;ret&nbsp;=&nbsp;1;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='621'>621</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;struct&nbsp;pollfd&nbsp;fdsnd;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='622'>622</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;mqd_t&nbsp;mq;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='623'>623</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;tWagoSnmpMsg&nbsp;msg;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='624'>624</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(object&nbsp;==&nbsp;NULL)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='625'>625</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;-1;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='626'>626</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='627'>627</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;msg.type&nbsp;=&nbsp;MSG_TYPE_REGISTER_OID;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='628'>628</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;memcpy(msg.variable.sOID,&nbsp;object-&gt;anOID,&nbsp;object-&gt;anOID_length&nbsp;*&nbsp;sizeof(oid));</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='629'>629</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;msg.variable.sOID_length&nbsp;=&nbsp;object-&gt;anOID_length;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='630'>630</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='631'>631</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;mq&nbsp;=&nbsp;_OpenClientQueue(TRAP_AGENT_MQ,&nbsp;sizeof(tWagoSnmpMsg),&nbsp;1);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='632'>632</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(mq&nbsp;&gt;=&nbsp;0)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='633'>633</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;fdsnd.fd&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;mq;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='634'>634</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;fdsnd.events&nbsp;&nbsp;=&nbsp;POLLOUT;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='635'>635</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;fdsnd.revents&nbsp;=&nbsp;0;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='636'>636</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(0&nbsp;&lt;&nbsp;poll(&amp;fdsnd,&nbsp;1,&nbsp;-1))&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='637'>637</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ret&nbsp;=&nbsp;mq_send(mq,&nbsp;(const&nbsp;char&nbsp;*)&amp;msg,&nbsp;sizeof(tWagoSnmpMsg),&nbsp;0);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='638'>638</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='639'>639</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;mq_close(mq);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='640'>640</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='641'>641</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;ret;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='642'>642</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='643'>643</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='644'>644</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;netsnmp_session&nbsp;*INTERNAL_GenerateSession_v1_v2c(char&nbsp;sHost[128],&nbsp;char&nbsp;sCommunity[64],&nbsp;long&nbsp;version)&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='645'>645</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;netsnmp_session&nbsp;tmpss;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='646'>646</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;netsnmp_session&nbsp;*ss;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='647'>647</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;netsnmp_transport&nbsp;*transport;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='648'>648</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;INIT_SNMP_ONCE;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='649'>649</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;snmp_sess_init(&amp;tmpss);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='650'>650</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='651'>651</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;tmpss.version&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;version;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='652'>652</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;tmpss.peername&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;sHost;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='653'>653</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;tmpss.community&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;(u_char&nbsp;*)sCommunity;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='654'>654</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;tmpss.community_len&nbsp;&nbsp;=&nbsp;strlen((char&nbsp;*)tmpss.community);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='655'>655</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;tmpss.callback&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;INTERNAL_SnmpInput;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='656'>656</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;tmpss.callback_magic&nbsp;=&nbsp;NULL;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='657'>657</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='658'>658</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;setup_engineID(NULL,&nbsp;NULL);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='659'>659</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(tmpss.contextEngineIDLen&nbsp;==&nbsp;0&nbsp;||&nbsp;tmpss.contextEngineID&nbsp;==&nbsp;NULL)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='660'>660</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;tmpss.contextEngineID&nbsp;=&nbsp;snmpv3_generate_engineID(&amp;tmpss.contextEngineIDLen);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='661'>661</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='662'>662</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;transport&nbsp;=&nbsp;netsnmp_transport_open_client("snmptrap",&nbsp;tmpss.peername);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='663'>663</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(transport&nbsp;==&nbsp;NULL)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='664'>664</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;NULL;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='665'>665</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='666'>666</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;ss&nbsp;=&nbsp;snmp_add(&amp;tmpss,&nbsp;transport,&nbsp;NULL,&nbsp;NULL);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='667'>667</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='668'>668</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;ss;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='669'>669</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='670'>670</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='671'>671</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;int&nbsp;INTERNAL_AddVarAndSend(char&nbsp;sOID[128],&nbsp;netsnmp_variable_list&nbsp;*stData,&nbsp;netsnmp_session&nbsp;*ss,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='672'>672</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;netsnmp_pdu&nbsp;*pdu)&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='673'>673</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;oid&nbsp;OID[MAX_OID_LEN];</td>
</tr>
<tr class="noCover">
<td class="line"><a name='674'>674</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;size_t&nbsp;OID_length;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='675'>675</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;tTrapVariableType&nbsp;var;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='676'>676</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;int&nbsp;ret&nbsp;=&nbsp;WAGOSNMP_RETURN_OK;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='677'>677</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;int&nbsp;status;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='678'>678</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='679'>679</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(ss&nbsp;==&nbsp;NULL)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='680'>680</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;WAGOSNMP_RETURN_INIT_SESSION_ERROR;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='681'>681</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='682'>682</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='683'>683</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;OID_length&nbsp;=&nbsp;MAX_OID_LEN;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='684'>684</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(sOID[0]&nbsp;!=&nbsp;0&nbsp;&amp;&amp;&nbsp;!SNMP_TLV_IS_NULL(stData))&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='685'>685</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;SNMP_MutexLock();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='686'>686</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(!snmp_parse_oid(sOID,&nbsp;OID,&nbsp;&amp;OID_length))&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='687'>687</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SNMP_MutexLock();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='688'>688</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;snmp_perror(sOID);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='689'>689</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;WAGOSNMP_RETURN_PARSE_OID_ERROR;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='690'>690</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='691'>691</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;SNMP_MutexUnlock();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='692'>692</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;ret&nbsp;=&nbsp;INTERNAL_ConvertTlvToTrapVar(&amp;var,&nbsp;stData);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='693'>693</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(ret&nbsp;!=&nbsp;WAGOSNMP_RETURN_OK)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='694'>694</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;ret;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='695'>695</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='696'>696</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(NULL&nbsp;==&nbsp;snmp_pdu_add_variable(pdu,&nbsp;OID,&nbsp;OID_length,&nbsp;var.type,&nbsp;var.buf,&nbsp;var.len))&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='697'>697</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;WAGOSNMP_RETURN_ERR_MALLOC;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='698'>698</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='699'>699</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='700'>700</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;status&nbsp;=&nbsp;snmp_send(ss,&nbsp;pdu)&nbsp;==&nbsp;0;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='701'>701</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='702'>702</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(status)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='703'>703</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;snmp_sess_perror("snmptrap",&nbsp;ss);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='704'>704</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;snmp_free_pdu(pdu);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='705'>705</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='706'>706</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;snmp_close(ss);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='707'>707</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;ret;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='708'>708</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='709'>709</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='710'>710</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;netsnmp_pdu&nbsp;*INTERNAL_GetTrap2PDU_v2_v3(char&nbsp;sEnterprise[128],&nbsp;tWagoSnmpReturnCode&nbsp;*result)&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='711'>711</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;netsnmp_pdu&nbsp;*pdu;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='712'>712</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;u_long&nbsp;uptime;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='713'>713</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;oid&nbsp;entOID[MAX_OID_LEN];</td>
</tr>
<tr class="noCover">
<td class="line"><a name='714'>714</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;size_t&nbsp;entOID_length;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='715'>715</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;*result&nbsp;=&nbsp;WAGOSNMP_RETURN_OK;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='716'>716</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='717'>717</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;pdu&nbsp;=&nbsp;snmp_pdu_create(SNMP_MSG_TRAP2);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='718'>718</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(!pdu)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='719'>719</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;fprintf(stderr,&nbsp;"Failed&nbsp;to&nbsp;create&nbsp;notification&nbsp;PDU\n");</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='720'>720</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;*result&nbsp;=&nbsp;WAGOSNMP_RETURN_ERR_MALLOC;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='721'>721</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;NULL;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='722'>722</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='723'>723</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='724'>724</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;/*snmp_add_var(pdu,&nbsp;objid_sysuptime,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='725'>725</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;sizeof(objid_sysuptime)&nbsp;/&nbsp;sizeof(oid),&nbsp;'t',&nbsp;trap);*/</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='726'>726</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;uptime&nbsp;=&nbsp;get_uptime();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='727'>727</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(NULL&nbsp;==&nbsp;snmp_pdu_add_variable(pdu,&nbsp;objid_sysuptime,&nbsp;sizeof(objid_sysuptime)&nbsp;/&nbsp;sizeof(oid),&nbsp;ASN_TIMETICKS,&nbsp;&amp;uptime,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='728'>728</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;sizeof(uptime)))&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='729'>729</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;*result&nbsp;=&nbsp;WAGOSNMP_RETURN_ERR_MALLOC;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='730'>730</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;NULL;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='731'>731</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='732'>732</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='733'>733</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;entOID_length&nbsp;=&nbsp;MAX_OID_LEN;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='734'>734</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;SNMP_MutexLock();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='735'>735</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(!snmp_parse_oid(sEnterprise,&nbsp;entOID,&nbsp;&amp;entOID_length))&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='736'>736</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;SNMP_MutexUnlock();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='737'>737</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;snmp_perror(sEnterprise);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='738'>738</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;*result&nbsp;=&nbsp;WAGOSNMP_RETURN_PARSE_OID_ERROR;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='739'>739</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;NULL;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='740'>740</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='741'>741</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;SNMP_MutexUnlock();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='742'>742</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if&nbsp;(NULL&nbsp;==&nbsp;snmp_pdu_add_variable(pdu,&nbsp;objid_snmptrap,&nbsp;sizeof(objid_snmptrap)&nbsp;/&nbsp;sizeof(oid),&nbsp;ASN_OBJECT_ID,&nbsp;entOID,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='743'>743</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;entOID_length&nbsp;*&nbsp;sizeof(oid)))&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='744'>744</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;NULL;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='745'>745</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='746'>746</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;pdu;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='747'>747</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='748'>748</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='749'>749</a></td>
<td class="hits"></td>
<td class="code">/*&nbsp;libnetsnmp&nbsp;*/</td>
</tr>
<tr class="noCover">
<td class="line"><a name='750'>750</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='751'>751</a></td>
<td class="hits"></td>
<td class="code">static&nbsp;pthread_mutex_t&nbsp;snmp_mutex;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='752'>752</a></td>
<td class="hits"></td>
<td class="code">static&nbsp;pthread_once_t&nbsp;snmp_mutex_init_once&nbsp;=&nbsp;PTHREAD_ONCE_INIT;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='753'>753</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='754'>754</a></td>
<td class="hits">0</td>
<td class="code">static&nbsp;void&nbsp;snmp_mutex_init()&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='755'>755</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;pthread_mutexattr_t&nbsp;attr&nbsp;=&nbsp;{0};</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='756'>756</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;int&nbsp;err&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;pthread_mutexattr_init(&amp;attr);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='757'>757</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='758'>758</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;error(err,&nbsp;err,&nbsp;"pthread_mutexattr_init");</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='759'>759</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;err&nbsp;=&nbsp;pthread_mutexattr_setprotocol(&amp;attr,&nbsp;PTHREAD_PRIO_INHERIT);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='760'>760</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;error(err,&nbsp;err,&nbsp;"pthread_mutexattr_setprotocol");</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='761'>761</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;err&nbsp;=&nbsp;pthread_mutex_init(&amp;snmp_mutex,&nbsp;&amp;attr);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='762'>762</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;error(err,&nbsp;err,&nbsp;"pthread_mutex_init");</td>
</tr>
<tr class="noCover">
<td class="line"><a name='763'>763</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='764'>764</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='765'>765</a></td>
<td class="hits">0</td>
<td class="code">void&nbsp;SNMP_MutexLock(void)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='766'>766</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;pthread_once(&amp;snmp_mutex_init_once,&nbsp;snmp_mutex_init);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='767'>767</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;pthread_mutex_lock(&amp;snmp_mutex);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='768'>768</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='769'>769</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='770'>770</a></td>
<td class="hits">0</td>
<td class="code">void&nbsp;SNMP_MutexUnlock(void)&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='771'>771</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;pthread_mutex_unlock(&amp;snmp_mutex);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='772'>772</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='773'>773</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='774'>774</a></td>
<td class="hits"></td>
<td class="code">//----&nbsp;End&nbsp;of&nbsp;source&nbsp;file&nbsp;------------------------------------------------------</td>
</tr>
